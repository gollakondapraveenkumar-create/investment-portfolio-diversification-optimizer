/**
 * static/js/charts.js
 * Dual Financial Charting Engine:
 * 1. Chart.js (Professional institutional charts when library is present)
 * 2. HTML5 Canvas Fallback (Zero-dependency standalone rendering)
 */

class ChartEngine {
  static instances = {};

  static formatINR(val) {
    return "₹" + Math.round(val).toLocaleString("en-IN");
  }

  // --------------------------------------------------------------------------
  // 1. Asset Allocation Donut Chart (Chart.js / Canvas Fallback)
  // --------------------------------------------------------------------------
  static renderDonutChart(canvas, data) {
    if (!canvas || !data || !data.allocations) return;

    const allocations = data.allocations.filter(a => a.weight > 0.001);
    const labels = allocations.map(a => a.name);
    const amounts = allocations.map(a => a.amount);
    const colors = allocations.map(a => a.color || (a.category === "Equity" ? "#2563eb" : a.category === "Debt" ? "#10b981" : "#f59e0b"));

    if (typeof Chart !== "undefined") {
      if (this.instances.donut) {
        this.instances.donut.destroy();
      }

      const ctx = canvas.getContext("2d");
      this.instances.donut = new Chart(ctx, {
        type: "doughnut",
        data: {
          labels: labels,
          datasets: [{
            data: amounts,
            backgroundColor: colors,
            borderColor: "#ffffff",
            borderWidth: 2,
            hoverOffset: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: "65%",
          plugins: {
            legend: {
              position: "bottom",
              labels: {
                boxWidth: 12,
                padding: 14,
                font: { family: "Inter", size: 12, weight: 600 },
                color: "#0f172a"
              }
            },
            tooltip: {
              backgroundColor: "#0f172a",
              titleFont: { family: "Inter", size: 13, weight: 700 },
              bodyFont: { family: "JetBrains Mono", size: 12 },
              padding: 12,
              callbacks: {
                label: function(context) {
                  const idx = context.dataIndex;
                  const amt = amounts[idx];
                  const pct = allocations[idx].weight_pct;
                  return ` Capital: ₹${Math.round(amt).toLocaleString("en-IN")} (${pct}%)`;
                }
              }
            }
          }
        }
      });
      return;
    }

    // Canvas Fallback
    this._renderCanvasDonut(canvas, allocations);
  }

  static _renderCanvasDonut(canvas, allocations) {
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const w = rect.width || 300;
    const h = rect.height || 260;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);

    const cx = w / 2;
    const cy = h / 2 - 15;
    const radius = Math.min(cx, cy) - 10;
    const innerRadius = radius * 0.62;

    ctx.clearRect(0, 0, w, h);

    let startAngle = -Math.PI / 2;
    allocations.forEach(a => {
      const slice = a.weight * (Math.PI * 2);
      ctx.fillStyle = a.color || "#2563eb";
      ctx.beginPath();
      ctx.arc(cx, cy, radius, startAngle, startAngle + slice);
      ctx.arc(cx, cy, innerRadius, startAngle + slice, startAngle, true);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();
      startAngle += slice;
    });

    // Center text
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 13px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("Optimal", cx, cy - 8);
    ctx.font = "11px Inter, sans-serif";
    ctx.fillStyle = "#475569";
    ctx.fillText("Allocation", cx, cy + 10);
  }

  // --------------------------------------------------------------------------
  // 2. Historical Returns Multi-Bar Chart (Chart.js / Canvas Fallback)
  // --------------------------------------------------------------------------
  static renderHistoricalBarChart(canvas, rawTable) {
    if (!canvas || !rawTable || rawTable.length === 0) return;

    const years = rawTable.map(r => r.year);
    const eq = rawTable.map(r => r.Equity);
    const debt = rawTable.map(r => r.Debt);
    const gold = rawTable.map(r => r.Gold);

    if (typeof Chart !== "undefined") {
      if (this.instances.historicalBar) {
        this.instances.historicalBar.destroy();
      }

      const ctx = canvas.getContext("2d");
      this.instances.historicalBar = new Chart(ctx, {
        type: "bar",
        data: {
          labels: years,
          datasets: [
            { label: "Equity %", data: eq, backgroundColor: "#2563eb", borderRadius: 4 },
            { label: "Debt %", data: debt, backgroundColor: "#10b981", borderRadius: 4 },
            { label: "Gold %", data: gold, backgroundColor: "#f59e0b", borderRadius: 4 }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              grid: { color: "#e2e8f0" },
              ticks: {
                color: "#475569",
                font: { family: "JetBrains Mono", size: 10 },
                callback: v => v + "%"
              }
            },
            x: {
              grid: { display: false },
              ticks: { color: "#475569", font: { family: "JetBrains Mono", size: 10 } }
            }
          },
          plugins: {
            legend: {
              position: "top",
              labels: { boxWidth: 10, font: { family: "Inter", size: 11, weight: 600 }, color: "#0f172a" }
            },
            tooltip: {
              backgroundColor: "#0f172a",
              callbacks: {
                label: c => ` ${c.dataset.label}: ${c.raw}%`
              }
            }
          }
        }
      });
      return;
    }
  }

  // --------------------------------------------------------------------------
  // 3. 10-Year Backtesting Wealth Compounding Chart
  // --------------------------------------------------------------------------
  static renderBacktestChart(canvas, btData) {
    if (!canvas || !btData || !btData.strategies) return;

    const years = btData.years || ["Start", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024"];
    const stratNames = Object.keys(btData.strategies);

    const colorMap = {
      "DP Optimal": "#d97706",
      "Markowitz MPT": "#8b5cf6",
      "60/40 Classic": "#0284c7",
      "100% Equity": "#e11d48",
      "Equal Weight (1/N)": "#059669",
      "Risk Parity": "#14b8a6"
    };

    if (typeof Chart !== "undefined") {
      if (this.instances.backtest) {
        this.instances.backtest.destroy();
      }

      const datasets = stratNames.map(name => {
        const s = btData.strategies[name];
        const isOptimal = name === "DP Optimal";
        return {
          label: name,
          data: s.wealth_trajectory,
          borderColor: colorMap[name] || "#64748b",
          backgroundColor: colorMap[name] || "#64748b",
          borderWidth: isOptimal ? 3.5 : 2,
          pointRadius: isOptimal ? 4 : 2,
          tension: 0.25,
          borderDash: name === "100% Equity" ? [4, 4] : []
        };
      });

      const ctx = canvas.getContext("2d");
      this.instances.backtest = new Chart(ctx, {
        type: "line",
        data: { labels: years, datasets: datasets },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              grid: { color: "#e2e8f0" },
              ticks: {
                color: "#475569",
                font: { family: "JetBrains Mono", size: 11 },
                callback: v => "₹" + Math.round(v).toLocaleString("en-IN")
              }
            },
            x: {
              grid: { color: "#f1f5f9" },
              ticks: { color: "#475569", font: { family: "Inter", size: 11 } }
            }
          },
          plugins: {
            legend: {
              position: "top",
              labels: { boxWidth: 12, padding: 12, font: { family: "Inter", size: 12, weight: 600 }, color: "#0f172a" }
            },
            tooltip: {
              backgroundColor: "#0f172a",
              callbacks: {
                label: c => ` ${c.dataset.label}: ₹${Math.round(c.raw).toLocaleString("en-IN")}`
              }
            }
          }
        }
      });
      return;
    }

    // Canvas fallback
    this._renderCanvasBacktest(canvas, btData);
  }

  static _renderCanvasBacktest(canvas, btData) {
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width || 700;
    const height = rect.height || 360;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);

    const pad = { left: 80, right: 30, top: 20, bottom: 40 };
    const plotW = width - pad.left - pad.right;
    const plotH = height - pad.top - pad.bottom;

    const strats = Object.entries(btData.strategies);
    let minW = btData.initial_capital * 0.8;
    let maxW = btData.initial_capital * 1.5;

    strats.forEach(([_, s]) => {
      s.wealth_trajectory.forEach(w => {
        if (w < minW) minW = w;
        if (w > maxW) maxW = w;
      });
    });

    const toX = (idx, total) => pad.left + (idx / (total - 1)) * plotW;
    const toY = (w) => pad.top + plotH - ((w - minW) / (maxW - minW)) * plotH;

    ctx.clearRect(0, 0, width, height);

    // Draw Grid
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    ctx.font = "11px 'JetBrains Mono', monospace";
    ctx.fillStyle = "#64748b";

    for (let i = 0; i <= 5; i++) {
      const wVal = minW + (i / 5) * (maxW - minW);
      const y = toY(wVal);
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(pad.left + plotW, y);
      ctx.stroke();
      ctx.fillText("₹" + Math.round(wVal).toLocaleString("en-IN"), 6, y + 4);
    }

    const nPoints = btData.years.length;
    btData.years.forEach((yr, idx) => {
      const x = toX(idx, nPoints);
      ctx.fillText(yr, x - 12, height - 12);
    });

    const colorMap = {
      "DP Optimal": "#d97706",
      "Markowitz MPT": "#8b5cf6",
      "60/40 Classic": "#0284c7",
      "100% Equity": "#e11d48",
      "Equal Weight (1/N)": "#059669"
    };

    strats.forEach(([name, s]) => {
      ctx.strokeStyle = colorMap[name] || "#64748b";
      ctx.lineWidth = name === "DP Optimal" ? 3.5 : 2;
      ctx.beginPath();
      s.wealth_trajectory.forEach((w, idx) => {
        const x = toX(idx, nPoints);
        const y = toY(w);
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    });
  }

  // --------------------------------------------------------------------------
  // 4. Markowitz Efficient Frontier & Feasible Monte Carlo Cloud
  // --------------------------------------------------------------------------
  static renderFrontierChart(canvas, data) {
    if (!canvas) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    const width = rect.width || 700;
    const height = rect.height || 380;
    canvas.width = width * dpr;
    canvas.height = height * dpr;

    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);

    const pad = { left: 75, right: 30, top: 30, bottom: 50 };
    const plotW = width - pad.left - pad.right;
    const plotH = height - pad.top - pad.bottom;

    let minX = 0.03, maxX = 0.22;
    let minY = 0.04, maxY = 0.18;

    if (data.cloud && data.cloud.length > 0) {
      const vols = data.cloud.map(p => p.volatility_pct / 100);
      const rets = data.cloud.map(p => p.expected_return_pct / 100);
      minX = Math.max(0.01, Math.min(...vols) * 0.85);
      maxX = Math.max(...vols) * 1.15;
      minY = Math.max(0.01, Math.min(...rets) * 0.85);
      maxY = Math.max(...rets) * 1.15;
    }

    const toX = (val) => pad.left + ((val - minX) / (maxX - minX)) * plotW;
    const toY = (val) => pad.top + plotH - ((val - minY) / (maxY - minY)) * plotH;

    ctx.clearRect(0, 0, width, height);

    // Grid lines
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;
    ctx.font = "11px 'JetBrains Mono', monospace";
    ctx.fillStyle = "#64748b";

    for (let i = 0; i <= 5; i++) {
      const vx = minX + (i / 5) * (maxX - minX);
      const x = toX(vx);
      ctx.beginPath();
      ctx.moveTo(x, pad.top);
      ctx.lineTo(x, pad.top + plotH);
      ctx.stroke();
      ctx.fillText((vx * 100).toFixed(1) + "%", x - 12, pad.top + plotH + 22);

      const vy = minY + (i / 5) * (maxY - minY);
      const y = toY(vy);
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(pad.left + plotW, y);
      ctx.stroke();
      ctx.fillText((vy * 100).toFixed(1) + "%", 14, y + 4);
    }

    // Axis Labels
    ctx.font = "bold 12px Inter, sans-serif";
    ctx.fillStyle = "#0f172a";
    ctx.fillText("Portfolio Risk (Annualized Volatility σ_p)", pad.left + plotW / 2 - 90, height - 10);

    ctx.save();
    ctx.translate(14, pad.top + plotH / 2 + 50);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Expected Annual Return E[R_p]", 0, 0);
    ctx.restore();

    // 1. Draw Monte Carlo Cloud
    if (data.cloud) {
      data.cloud.forEach(pt => {
        const x = toX(pt.volatility_pct / 100);
        const y = toY(pt.expected_return_pct / 100);
        const sr = pt.sharpe_ratio;
        ctx.fillStyle = sr > 0.8 ? "rgba(16, 185, 129, 0.45)" : sr > 0.5 ? "rgba(37, 99, 235, 0.35)" : "rgba(148, 163, 184, 0.3)";
        ctx.beginPath();
        ctx.arc(x, y, 2.5, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    // 2. Draw Efficient Frontier Curve
    if (data.frontier && data.frontier.length > 1) {
      ctx.strokeStyle = "#8b5cf6";
      ctx.lineWidth = 3;
      ctx.beginPath();
      data.frontier.forEach((pt, idx) => {
        const x = toX(pt.volatility_pct / 100);
        const y = toY(pt.expected_return_pct / 100);
        if (idx === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }

    // 3. Draw Standalone Assets
    if (data.assets) {
      data.assets.forEach(asset => {
        const x = toX(asset.volatility);
        const y = toY(asset.expected_return);
        ctx.fillStyle = asset.color || "#2563eb";
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.fillStyle = "#0f172a";
        ctx.font = "bold 11px Inter, sans-serif";
        ctx.fillText(asset.ticker || asset.name, x + 8, y + 4);
      });
    }

    // 4. Draw DP Optimal Point
    if (data.dpPoint) {
      const x = toX(data.dpPoint.volatility);
      const y = toY(data.dpPoint.expected_return);

      // Glowing outer ring
      ctx.strokeStyle = "rgba(217, 119, 6, 0.35)";
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.arc(x, y, 16, 0, Math.PI * 2);
      ctx.stroke();

      // Gold core point
      ctx.fillStyle = "#f59e0b";
      ctx.beginPath();
      ctx.arc(x, y, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = "#92400e";
      ctx.font = "bold 12px Inter, sans-serif";
      ctx.fillText("★ DP Optimal", x + 12, y - 8);
    }
  }
}
