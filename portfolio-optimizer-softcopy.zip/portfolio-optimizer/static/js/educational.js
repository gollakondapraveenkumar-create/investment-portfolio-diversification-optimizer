/**
 * static/js/educational.js
 * Interactive Quantitative Finance Learning Module & Student Knowledge Sandbox.
 * Covers Bellman Principle of Optimality, Modern Portfolio Theory, and Diversification.
 */

class EducationalModule {
  static init() {
    this.setupDiversificationLab();
    this.setupQuiz();
  }

  static setupDiversificationLab() {
    const slider = document.getElementById("edu-corr-slider");
    const valDisplay = document.getElementById("edu-corr-val");
    const riskDisplay = document.getElementById("edu-port-vol");
    const bonusDisplay = document.getElementById("edu-risk-eliminated");

    if (!slider) return;

    const updateLab = () => {
      const rho = parseFloat(slider.value);
      valDisplay.textContent = (rho > 0 ? "+" : "") + rho.toFixed(2);

      // 50% Equity (sigma=0.175), 50% Gold (sigma=0.135)
      const w1 = 0.5, w2 = 0.5;
      const s1 = 0.175, s2 = 0.135;

      const varP = (w1 * s1) ** 2 + (w2 * s2) ** 2 + 2 * w1 * w2 * rho * s1 * s2;
      const volP = Math.sqrt(Math.max(0, varP));
      const undivVol = w1 * s1 + w2 * s2; // 0.155 (15.5%)

      const bonusPct = ((1 - volP / undivVol) * 100);

      riskDisplay.textContent = (volP * 100).toFixed(2) + "%";
      bonusDisplay.textContent = (bonusPct >= 0 ? bonusPct.toFixed(1) : "0.0") + "%";
    };

    slider.addEventListener("input", updateLab);
    updateLab();
  }

  static setupQuiz() {
    const quizContainer = document.getElementById("quiz-container");
    if (!quizContainer) return;

    const questions = [
      {
        q: "1. Why does adding Gold (which has a lower return than Equities) often INCREASE a portfolio's Sharpe ratio?",
        options: [
          { text: "Gold guarantees a fixed risk-free return every single year.", correct: false },
          { text: "Its low correlation with equities reduces portfolio variance by more than it reduces expected return.", correct: true },
          { text: "Gold increases the market beta above 1.5, driving aggressive speculative gains.", correct: false },
          { text: "Dynamic programming forces all weights to be strictly equal across all assets.", correct: false }
        ],
        explanation: "Correct! When assets have near-zero or negative correlation, cross-asset covariance terms shrink portfolio volatility (sigma_p) substantially. This reduction in the denominator often outpaces the slight decline in expected return, boosting the Sharpe ratio (excess return per unit of risk)."
      },
      {
        q: "2. In our Dynamic Programming optimizer, what does the state DP[i][b] mathematically represent?",
        options: [
          { text: "The maximum price of asset i observed over b days.", correct: false },
          { text: "The optimal risk-adjusted allocation considering the first i assets with total budget b.", correct: true },
          { text: "The total fee paid to brokers for rebalancing asset i with b trades.", correct: false },
          { text: "The probability that asset i will default within b months.", correct: false }
        ],
        explanation: "Correct! Bellman's principle of optimality defines state DP[i][b] as the optimal subproblem solution for allocating b units of capital among the subset of the first i investable assets, enabling efficient bottom-up computation."
      },
      {
        q: "3. What is the value of the Diversification Ratio (DR = sum(w_i * sigma_i) / sigma_p) when all assets are perfectly correlated (rho = +1.0)?",
        options: [
          { text: "Exactly 1.0 (no diversification benefit whatsoever).", correct: true },
          { text: "Approaches infinity (infinite free lunch).", correct: false },
          { text: "Exactly 0.0 (total capital destruction).", correct: false },
          { text: "Equal to the risk-free treasury rate.", correct: false }
        ],
        explanation: "Correct! When rho = +1.0, portfolio standard deviation equals the exact weighted linear sum of individual standard deviations (sigma_p = sum(w_i * sigma_i)). Hence DR = 1.0, meaning zero risk reduction is achieved."
      },
      {
        q: "4. When an investor shifts risk tolerance from Conservative (1.0) to Aggressive (10.0), how does the Arrow-Pratt risk penalty lambda behave?",
        options: [
          { text: "Lambda drops significantly, reducing the penalty on portfolio variance and favoring higher expected return.", correct: true },
          { text: "Lambda increases to infinity to eliminate all possible downside.", correct: false },
          { text: "Lambda remains completely constant regardless of user preference.", correct: false },
          { text: "Lambda forces the optimizer to put 100% of the budget into AAA debt.", correct: false }
        ],
        explanation: "Correct! Utility is U(w) = E[R_p] - (lambda / 2) * Var_p. An aggressive investor has low risk aversion (small lambda), so the optimizer prioritizes assets with high expected returns even if variance is elevated."
      }
    ];

    let html = "";
    questions.forEach((qObj, qIdx) => {
      html += `
        <div class="edu-card" style="margin-bottom: 20px;">
          <h4 style="font-size: 14px; margin-bottom: 12px; color: #fff;">${qObj.q}</h4>
          <div class="quiz-options-group" data-qindex="${qIdx}">
      `;

      qObj.options.forEach((opt, optIdx) => {
        html += `
          <div class="quiz-option" data-optindex="${optIdx}" data-correct="${opt.correct}">
            <span style="font-weight: 600; width: 22px;">${String.fromCharCode(65 + optIdx)}.</span>
            <span>${opt.text}</span>
          </div>
        `;
      });

      html += `
          </div>
          <div class="quiz-feedback" id="feedback-${qIdx}"></div>
        </div>
      `;
    });

    quizContainer.innerHTML = html;

    // Attach click handlers
    document.querySelectorAll(".quiz-option").forEach(el => {
      el.addEventListener("click", function() {
        const parent = this.closest(".quiz-options-group");
        const qIndex = parseInt(parent.dataset.qindex);
        const isCorrect = this.dataset.correct === "true";
        const feedbackEl = document.getElementById(`feedback-${qIndex}`);

        // Disable siblings
        parent.querySelectorAll(".quiz-option").forEach(opt => {
          opt.style.pointerEvents = "none";
          if (opt.dataset.correct === "true") {
            opt.classList.add("correct");
          }
        });

        if (!isCorrect) {
          this.classList.add("wrong");
        }

        feedbackEl.style.display = "block";
        feedbackEl.style.background = isCorrect ? "rgba(16, 185, 129, 0.15)" : "rgba(244, 63, 94, 0.15)";
        feedbackEl.style.border = isCorrect ? "1px solid rgba(16, 185, 129, 0.4)" : "1px solid rgba(244, 63, 94, 0.4)";
        feedbackEl.style.color = isCorrect ? "#6ee7b7" : "#fda4af";
        feedbackEl.innerHTML = `<strong>${isCorrect ? "Spot on!" : "Incorrect."}</strong> ${questions[qIndex].explanation}`;
      });
    });
  }
}
