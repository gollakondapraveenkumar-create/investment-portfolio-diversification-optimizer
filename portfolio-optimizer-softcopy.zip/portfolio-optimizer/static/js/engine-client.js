/**
 * engine-client.js
 * Client-side mirror of the Python Object-Oriented Financial Engine.
 * Allows instant, zero-latency optimization in any browser without requiring a backend server.
 */

class AssetClassClient {
  constructor({ name, ticker, category, expected_return, volatility, historical_returns, description, color }) {
    this.name = name;
    this.ticker = ticker;
    this.category = category;
    this.expected_return = expected_return;
    this.volatility = volatility;
    this.historical_returns = historical_returns;
    this.description = description;
    this.color = color;
  }
}

class EquityAssetClient extends AssetClassClient {
  constructor(opts) {
    super({ ...opts, category: 'Equity' });
    this.beta = opts.beta || 1.0;
    this.dividend_yield = opts.dividend_yield || 0.015;
    this.market_cap_tier = opts.market_cap_tier || 'Large Cap';
  }
}

class DebtAssetClient extends AssetClassClient {
  constructor(opts) {
    super({ ...opts, category: 'Debt' });
    this.credit_rating = opts.credit_rating || 'AAA Sovereign';
    this.duration_years = opts.duration_years || 6.5;
    this.coupon_rate = opts.coupon_rate || 0.04;
    this.ytm = opts.ytm || 0.045;
  }
}

class GoldAssetClient extends AssetClassClient {
  constructor(opts) {
    super({ ...opts, category: 'Gold' });
    this.form = opts.form || 'Physical Bullion';
    this.expense_ratio = opts.expense_ratio || 0.0025;
    this.safe_haven_score = opts.safe_haven_score || 9.5;
  }
}

class CorrelationMatrixClient {
  constructor(assetNames, matrix) {
    this.asset_names = assetNames;
    this.matrix = matrix;
  }

  getCorrelation(i, j) {
    return i === j ? 1.0 : this.matrix[i][j];
  }

  computeCovarianceMatrix(volatilities) {
    const n = volatilities.length;
    const cov = Array.from({ length: n }, () => Array(n).fill(0));
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        cov[i][j] = this.getCorrelation(i, j) * volatilities[i] * volatilities[j];
      }
    }
    return cov;
  }
}

class PortfolioClient {
  constructor(assets, weights, budget = 100000, corrMatrix = null, rf = 0.035) {
    this.assets = assets;
    this.total_budget = budget;
    this.risk_free_rate = rf;
    this.correlation_matrix = corrMatrix;

    let sumW = weights.reduce((a, b) => a + b, 0);
    this.weights = sumW > 0 ? weights.map(w => w / sumW) : weights;

    const vols = this.assets.map(a => a.volatility);
    this.cov = corrMatrix ? corrMatrix.computeCovarianceMatrix(vols) : this._identityCov(vols);
  }

  _identityCov(vols) {
    const n = vols.length;
    const c = Array.from({ length: n }, () => Array(n).fill(0));
    for (let i = 0; i < n; i++) c[i][i] = vols[i] ** 2;
    return c;
  }

  get expected_return() {
    return this.weights.reduce((sum, w, i) => sum + w * this.assets[i].expected_return, 0);
  }

  get variance() {
    let v = 0;
    const n = this.weights.length;
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        v += this.weights[i] * this.weights[j] * this.cov[i][j];
      }
    }
    return Math.max(0, v);
  }

  get volatility() {
    return Math.sqrt(this.variance);
  }

  get sharpe_ratio() {
    return this.volatility > 1e-6 ? (this.expected_return - this.risk_free_rate) / this.volatility : 0;
  }

  get weighted_average_volatility() {
    return this.weights.reduce((sum, w, i) => sum + w * this.assets[i].volatility, 0);
  }

  get diversification_ratio() {
    return this.volatility > 1e-6 ? this.weighted_average_volatility / this.volatility : 1.0;
  }

  get diversification_bonus_pct() {
    const undiv = this.weighted_average_volatility;
    return undiv > 1e-6 ? Math.max(0, (1 - this.volatility / undiv) * 100) : 0;
  }

  valueAtRisk(confidence = 0.95, horizon = 1.0) {
    const zMap = { 0.90: 1.282, 0.95: 1.645, 0.99: 2.326 };
    const z = zMap[confidence] || 1.645;
    const lossPct = (z * this.volatility * Math.sqrt(horizon)) - (this.expected_return * horizon);
    return Math.max(0, lossPct * this.total_budget);
  }

  conditionalVar(confidence = 0.95, horizon = 1.0) {
    const zMap = { 0.90: 1.282, 0.95: 1.645, 0.99: 2.326 };
    const phiMap = { 0.90: 0.1755, 0.95: 0.1031, 0.99: 0.0267 };
    const z = zMap[confidence] || 1.645;
    const phi = phiMap[confidence] || 0.1031;
    const tailFactor = phi / (1.0 - confidence);
    const lossPct = (tailFactor * this.volatility * Math.sqrt(horizon)) - (this.expected_return * horizon);
    return Math.max(0, lossPct * this.total_budget);
  }

  toDict() {
    const allocations = this.assets.map((a, i) => ({
      name: a.name,
      ticker: a.ticker,
      category: a.category,
      color: a.color,
      weight: parseFloat(this.weights[i].toFixed(4)),
      weight_pct: parseFloat((this.weights[i] * 100).toFixed(2)),
      amount: parseFloat((this.weights[i] * this.total_budget).toFixed(2)),
      expected_return: a.expected_return,
      volatility: a.volatility
    }));

    const catBreakdown = {
      Equity: { weight: 0, amount: 0, weight_pct: 0 },
      Debt: { weight: 0, amount: 0, weight_pct: 0 },
      Gold: { weight: 0, amount: 0, weight_pct: 0 }
    };

    allocations.forEach(al => {
      if (!catBreakdown[al.category]) {
        catBreakdown[al.category] = { weight: 0, amount: 0, weight_pct: 0 };
      }
      catBreakdown[al.category].weight += al.weight;
      catBreakdown[al.category].amount += al.amount;
    });

    Object.keys(catBreakdown).forEach(k => {
      catBreakdown[k].weight_pct = parseFloat((catBreakdown[k].weight * 100).toFixed(2));
      catBreakdown[k].amount = parseFloat(catBreakdown[k].amount.toFixed(2));
    });

    const varAmt = this.valueAtRisk(0.95);
    const cvarAmt = this.conditionalVar(0.95);

    return {
      total_budget: this.total_budget,
      expected_return: parseFloat(this.expected_return.toFixed(4)),
      expected_return_pct: parseFloat((this.expected_return * 100).toFixed(2)),
      volatility: parseFloat(this.volatility.toFixed(4)),
      volatility_pct: parseFloat((this.volatility * 100).toFixed(2)),
      variance: parseFloat(this.variance.toFixed(6)),
      sharpe_ratio: parseFloat(this.sharpe_ratio.toFixed(3)),
      undiversified_volatility_pct: parseFloat((this.weighted_average_volatility * 100).toFixed(2)),
      diversification_ratio: parseFloat(this.diversification_ratio.toFixed(3)),
      diversification_bonus_pct: parseFloat(this.diversification_bonus_pct.toFixed(2)),
      var_95_amount: parseFloat(varAmt.toFixed(2)),
      var_95_pct: parseFloat(((varAmt / this.total_budget) * 100).toFixed(2)),
      cvar_95_amount: parseFloat(cvarAmt.toFixed(2)),
      cvar_95_pct: parseFloat(((cvarAmt / this.total_budget) * 100).toFixed(2)),
      allocations,
      category_breakdown: catBreakdown
    };
  }
}

class DynamicProgrammingOptimizerClient {
  constructor(stepPct = 2.0) {
    this.stepPct = stepPct;
    this.lastDPTable = null;
    this.lastBacktrackTrace = null;
  }

  _riskLambda(riskTolerance) {
    const clamped = Math.max(1.0, Math.min(10.0, riskTolerance));
    return 28.0 / Math.pow(clamped, 1.3);
  }

  optimize(assets, budget, riskTolerance, corrMatrix, rf = 0.035) {
    const n = assets.length;
    const step = Math.max(1.0, Math.min(10.0, this.stepPct));
    const M = Math.round(100.0 / step);
    const lambdaRisk = this._riskLambda(riskTolerance);
    const cov = corrMatrix.computeCovarianceMatrix(assets.map(a => a.volatility));

    // DP Table: dp[stage][budget_units]
    const dp = Array.from({ length: n }, () => Array(M + 1).fill(null));

    const computeMetrics = (wList) => {
      let ret = 0;
      let vr = 0;
      for (let i = 0; i < wList.length; i++) {
        ret += wList[i] * assets[i].expected_return;
        for (let j = 0; j < wList.length; j++) {
          vr += wList[i] * wList[j] * cov[i][j];
        }
      }
      const vol = Math.sqrt(Math.max(0, vr));
      const util = ret - 0.5 * lambdaRisk * vr;
      return { ret, vol, util };
    };

    // Stage 0: First Asset Base Case
    for (let b = 0; b <= M; b++) {
      const w = Array(n).fill(0);
      w[0] = b / M;
      const { ret, vol, util } = computeMetrics(w);
      dp[0][b] = {
        utility: util,
        expected_return: ret,
        volatility: vol,
        alloc_units: b,
        alloc_pct: (b / M) * 100,
        weights: w,
        from_b: 0
      };
    }

    // Stages 1 to n - 1
    for (let i = 1; i < n; i++) {
      for (let b = 0; b <= M; b++) {
        let bestCell = null;
        let bestU = -Infinity;

        for (let x = 0; x <= b; x++) {
          const prevB = b - x;
          const prevCell = dp[i - 1][prevB];
          if (!prevCell) continue;

          const candW = [...prevCell.weights];
          candW[i] = x / M;
          const { ret, vol, util } = computeMetrics(candW);

          if (util > bestU) {
            bestU = util;
            bestCell = {
              utility: util,
              expected_return: ret,
              volatility: vol,
              alloc_units: x,
              alloc_pct: (x / M) * 100,
              weights: candW,
              from_b: prevB
            };
          }
        }
        dp[i][b] = bestCell;
      }
    }

    const finalCell = dp[n - 1][M];
    const finalWeights = finalCell ? finalCell.weights : Array(n).fill(1 / n);

    // Build backtrack trace
    const trace = [];
    let currB = M;
    for (let i = n - 1; i >= 0; i--) {
      const cell = dp[i][currB];
      if (cell) {
        trace.push({
          stage: i,
          asset_name: assets[i].name,
          asset_ticker: assets[i].ticker,
          allocated_units: cell.alloc_units,
          allocated_pct: parseFloat(cell.alloc_pct.toFixed(2)),
          accumulated_return_pct: parseFloat((cell.expected_return * 100).toFixed(2)),
          accumulated_volatility_pct: parseFloat((cell.volatility * 100).toFixed(2)),
          utility: parseFloat(cell.utility.toFixed(4)),
          budget_at_stage_pct: parseFloat(((currB / M) * 100).toFixed(1)),
          transition_from_budget_pct: parseFloat(((cell.from_b / M) * 100).toFixed(1))
        });
        currB = cell.from_b;
      }
    }
    trace.reverse();

    // Downsample grid for UI display
    const sampleStride = Math.max(1, Math.floor(M / 20));
    const browserGrid = [];
    for (let i = 0; i < n; i++) {
      const row = [];
      for (let b = 0; b <= M; b += sampleStride) {
        const cell = dp[i][b];
        if (cell) {
          row.push({
            b_pct: parseFloat(((b / M) * 100).toFixed(1)),
            alloc_pct: parseFloat(cell.alloc_pct.toFixed(1)),
            return_pct: parseFloat((cell.expected_return * 100).toFixed(2)),
            vol_pct: parseFloat((cell.volatility * 100).toFixed(2)),
            utility: parseFloat(cell.utility.toFixed(4)),
            has_solution: true
          });
        } else {
          row.push({ b_pct: parseFloat(((b / M) * 100).toFixed(1)), has_solution: false });
        }
      }
      browserGrid.push({ stage: i, asset_name: assets[i].name, ticker: assets[i].ticker, cells: row });
    }

    this.lastDPTable = {
      num_stages: n,
      discretization_step_pct: step,
      total_units: M,
      risk_lambda: parseFloat(lambdaRisk.toFixed(3)),
      grid: browserGrid
    };
    this.lastBacktrackTrace = trace;

    return new PortfolioClient(assets, finalWeights, budget, corrMatrix, rf);
  }
}

class ClientMarketDataset {
  static get3AssetUniverse() {
    const eq = new EquityAssetClient({
      name: "Global Equity (Stock Market)",
      ticker: "EQTY",
      expected_return: 0.132,
      volatility: 0.175,
      historical_returns: [0.014, 0.120, 0.218, -0.044, 0.315, 0.184, 0.287, -0.181, 0.263, 0.155],
      beta: 1.0,
      dividend_yield: 0.018,
      market_cap_tier: "Large Cap Blend",
      description: "Ownership in productive corporations. High long-term compounding, high drawdown variance.",
      color: "#3b82f6"
    });

    const debt = new DebtAssetClient({
      name: "Government Sovereign Bonds",
      ticker: "DEBT",
      expected_return: 0.052,
      volatility: 0.062,
      historical_returns: [0.005, 0.026, 0.035, 0.000, 0.087, 0.075, -0.015, -0.130, 0.055, 0.042],
      credit_rating: "AAA Sovereign",
      duration_years: 6.5,
      coupon_rate: 0.045,
      ytm: 0.048,
      description: "Fixed-income sovereign securities providing coupon income and drawdown capital protection.",
      color: "#10b981"
    });

    const gold = new GoldAssetClient({
      name: "Precious Metals (Gold)",
      ticker: "GOLD",
      expected_return: 0.088,
      volatility: 0.135,
      historical_returns: [-0.104, 0.081, 0.131, -0.016, 0.183, 0.251, -0.036, -0.003, 0.131, 0.182],
      form: "Physical Bullion / Sovereign ETF",
      expense_ratio: 0.0025,
      safe_haven_score: 9.6,
      description: "Monetary reserve asset with near-zero equity correlation, hedging against currency shocks.",
      color: "#f59e0b"
    });

    const assets = [eq, debt, gold];
    const corrMatrix = [
      [1.00, 0.18, 0.04],
      [0.18, 1.00, 0.22],
      [0.04, 0.22, 1.00]
    ];

    return { assets, corr: new CorrelationMatrixClient(assets.map(a => a.name), corrMatrix) };
  }

  static get6AssetUniverse() {
    const eqLarge = new EquityAssetClient({
      name: "US Large Cap Blend", ticker: "SPY", expected_return: 0.128, volatility: 0.160,
      historical_returns: [0.014, 0.120, 0.218, -0.044, 0.315, 0.184, 0.287, -0.181, 0.263, 0.155],
      beta: 1.00, dividend_yield: 0.016, market_cap_tier: "Mega/Large", description: "Blue-chip benchmark.", color: "#2563eb"
    });
    const eqTech = new EquityAssetClient({
      name: "Tech & Innovation Growth", ticker: "QQQ", expected_return: 0.174, volatility: 0.235,
      historical_returns: [0.084, 0.059, 0.315, -0.010, 0.380, 0.476, 0.275, -0.326, 0.548, 0.210],
      beta: 1.28, dividend_yield: 0.006, market_cap_tier: "High Growth", description: "High-beta growth.", color: "#8b5cf6"
    });
    const debtGov = new DebtAssetClient({
      name: "10-Year Treasury Bonds", ticker: "IEF", expected_return: 0.046, volatility: 0.058,
      historical_returns: [0.005, 0.026, 0.035, 0.000, 0.087, 0.075, -0.015, -0.130, 0.055, 0.042],
      credit_rating: "AAA Sovereign", duration_years: 7.2, coupon_rate: 0.042, ytm: 0.044, description: "Benchmark treasuries.", color: "#059669"
    });
    const debtCorp = new DebtAssetClient({
      name: "Corporate Investment Grade", ticker: "LQD", expected_return: 0.062, volatility: 0.076,
      historical_returns: [-0.015, 0.062, 0.064, -0.025, 0.144, 0.099, -0.018, -0.178, 0.085, 0.051],
      credit_rating: "A/BBB Corporate", duration_years: 8.1, coupon_rate: 0.053, ytm: 0.057, description: "Senior corporate bonds.", color: "#14b8a6"
    });
    const goldPhys = new GoldAssetClient({
      name: "Physical Gold Bullion", ticker: "GLD", expected_return: 0.085, volatility: 0.132,
      historical_returns: [-0.104, 0.081, 0.131, -0.016, 0.183, 0.251, -0.036, -0.003, 0.131, 0.182],
      form: "Physical Bars", expense_ratio: 0.004, safe_haven_score: 9.8, description: "Pure physical bullion.", color: "#f59e0b"
    });
    const goldMiners = new GoldAssetClient({
      name: "Gold Mining & Royalties", ticker: "GDX", expected_return: 0.105, volatility: 0.245,
      historical_returns: [-0.247, 0.528, 0.111, -0.091, 0.398, 0.231, -0.095, -0.090, 0.105, 0.198],
      form: "Equities", expense_ratio: 0.0051, safe_haven_score: 6.8, description: "Operating leverage to gold.", color: "#d97706"
    });

    const assets = [eqLarge, eqTech, debtGov, debtCorp, goldPhys, goldMiners];
    const corrMatrix = [
      [1.00, 0.88, 0.12, 0.35, 0.03, 0.15],
      [0.88, 1.00, 0.05, 0.28, -0.02, 0.18],
      [0.12, 0.05, 1.00, 0.72, 0.24, 0.12],
      [0.35, 0.28, 0.72, 1.00, 0.18, 0.16],
      [0.03,-0.02, 0.24, 0.18, 1.00, 0.78],
      [0.15, 0.18, 0.12, 0.16, 0.78, 1.00]
    ];
    return { assets, corr: new CorrelationMatrixClient(assets.map(a => a.name), corrMatrix) };
  }
}
