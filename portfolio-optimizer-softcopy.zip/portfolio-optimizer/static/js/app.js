/**
 * static/js/app.js
 * Main Controller for Investment Portfolio Diversification Optimizer.
 * Connects UI inputs, handles REST API communication, executes Dynamic Programming,
 * and renders interactive Chart.js visualizations.
 */

const AppState = {
  mode: "3-asset",
  budget: 500000.0,      // Total budget in Indian Rupees (₹5,00,000 default)
  unitStep: 5000.0,      // Minimum investment unit in ₹ (₹5,000 default)
  riskTolerance: 5.0,    // 1.0 to 10.0
  maxRisk: null,         // Optional max portfolio risk ceiling %
  riskFreeRate: 0.035,   // 3.5% risk-free rate
  useBackend: true,
  lastOptimization: null,
  historicalData: null,
  cloudData: [],
  customAssets: {
    Equity: { return_pct: 15.86, vol_pct: 13.50, min_pct: 10, max_pct: 70 },
    Debt:   { return_pct: 7.95,  vol_pct: 3.77,  min_pct: 15, max_pct: 70 },
    Gold:   { return_pct: 9.92,  vol_pct: 12.47, min_pct: 5,  max_pct: 40 }
  }
};

document.addEventListener("DOMContentLoaded", async () => {
  initDOM();
  EducationalModule.init();
  await checkBackendAvailability();
  await loadHistoricalDataset();
  await runOptimization();
});

function formatINR(val) {
  return "₹" + Math.round(val).toLocaleString("en-IN");
}

function initDOM() {
  // Navigation Tabs Switching
  document.querySelectorAll(".nav-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".nav-tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-content-pane").forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      const targetId = btn.dataset.tab;
      const targetPane = document.getElementById(targetId);
      if (targetPane) {
        targetPane.classList.add("active");
        handleTabActivation(targetId);
      }
    });
  });

  // Hero CTA Button -> Switches to Optimizer tab
  const heroBtn = document.getElementById("btn-hero-optimize");
  if (heroBtn) {
    heroBtn.addEventListener("click", () => {
      const optTabBtn = document.querySelector(`.nav-tab-btn[data-tab="tab-optimizer"]`);
      if (optTabBtn) optTabBtn.click();
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  // Budget Input & Slider Synchronization
  const budgetInput = document.getElementById("budget-input");
  const budgetSlider = document.getElementById("budget-slider");
  const budgetBadge = document.getElementById("budget-badge");

  const syncBudget = (val) => {
    val = Math.max(10000, parseFloat(val) || 10000);
    AppState.budget = val;
    budgetInput.value = val;
    budgetSlider.value = Math.min(5000000, val);
    budgetBadge.textContent = formatINR(val);
  };

  budgetInput.addEventListener("input", (e) => syncBudget(e.target.value));
  budgetSlider.addEventListener("input", (e) => syncBudget(e.target.value));
  budgetInput.addEventListener("change", runOptimization);
  budgetSlider.addEventListener("change", runOptimization);

  // Preset Budget Buttons
  document.querySelectorAll(".preset-btn[data-budget]").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".preset-btn[data-budget]").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      syncBudget(btn.dataset.budget);
      runOptimization();
    });
  });

  // Unit Step Dropdown
  const unitSelect = document.getElementById("unit-step-select");
  const unitBadge = document.getElementById("unit-badge");
  unitSelect.addEventListener("change", (e) => {
    AppState.unitStep = parseFloat(e.target.value);
    unitBadge.textContent = formatINR(AppState.unitStep);
    runOptimization();
  });

  // Risk Tolerance Slider & Presets
  const riskSlider = document.getElementById("risk-slider");
  const riskBadge = document.getElementById("risk-badge");
  const riskProfile = document.getElementById("risk-profile-label");

  riskSlider.addEventListener("input", (e) => {
    AppState.riskTolerance = parseFloat(e.target.value);
    riskBadge.textContent = AppState.riskTolerance.toFixed(1);

    if (AppState.riskTolerance <= 3.0) {
      riskProfile.textContent = "Conservative (Capital Preservation & Stability Focus)";
      riskProfile.style.color = "#059669";
    } else if (AppState.riskTolerance <= 6.5) {
      riskProfile.textContent = "Balanced (Optimal Sharpe Maximization)";
      riskProfile.style.color = "#2563eb";
    } else {
      riskProfile.textContent = "Aggressive (High Capital Appreciation Focus)";
      riskProfile.style.color = "#d97706";
    }
  });
  riskSlider.addEventListener("change", runOptimization);

  // Quick Risk Presets
  document.querySelectorAll(".risk-preset").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".risk-preset").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const val = parseFloat(btn.dataset.risk);
      AppState.riskTolerance = val;
      riskSlider.value = val;
      riskSlider.dispatchEvent(new Event("input"));
      runOptimization();
    });
  });

  // Max Risk Ceiling Input
  const maxRiskInput = document.getElementById("max-risk-input");
  maxRiskInput.addEventListener("change", (e) => {
    const val = parseFloat(e.target.value);
    AppState.maxRisk = isNaN(val) ? null : val;
    runOptimization();
  });

  // Universe Mode Buttons
  document.querySelectorAll(".universe-mode-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".universe-mode-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      AppState.mode = btn.dataset.mode;
      renderParamTable();
      runOptimization();
    });
  });

  // Reset to Historical Button
  document.getElementById("btn-reset-historical").addEventListener("click", () => {
    if (AppState.historicalData && AppState.historicalData.statistics) {
      const stats = AppState.historicalData.statistics;
      AppState.customAssets = {
        Equity: { return_pct: stats.Equity.mean_return_pct, vol_pct: stats.Equity.volatility_pct, min_pct: 10, max_pct: 70 },
        Debt:   { return_pct: stats.Debt.mean_return_pct,   vol_pct: stats.Debt.volatility_pct,   min_pct: 15, max_pct: 70 },
        Gold:   { return_pct: stats.Gold.mean_return_pct,   vol_pct: stats.Gold.volatility_pct,   min_pct: 5,  max_pct: 40 }
      };
      renderParamTable();
      runOptimization();
    }
  });

  // Optimize Button
  document.getElementById("btn-run-optimization").addEventListener("click", runOptimization);

  // Initial Parameter Table Render
  renderParamTable();
}

function handleTabActivation(tabId) {
  if (!AppState.lastOptimization) return;

  if (tabId === "tab-frontier") {
    const canvas = document.getElementById("canvas-frontier");
    ChartEngine.renderFrontierChart(canvas, {
      cloud: AppState.cloudData,
      frontier: AppState.lastOptimization.efficient_frontier,
      dpPoint: AppState.lastOptimization.dp_optimal,
      assets: AppState.lastOptimization.dp_optimal.allocations
    });
  } else if (tabId === "tab-backtest") {
    const canvas = document.getElementById("canvas-backtest");
    ChartEngine.renderBacktestChart(canvas, AppState.lastOptimization.backtest);
  } else if (tabId === "tab-historical" && AppState.historicalData) {
    const canvas = document.getElementById("canvas-historical-bar");
    ChartEngine.renderHistoricalBarChart(canvas, AppState.historicalData.raw_table);
  }
}

function renderParamTable() {
  const tbody = document.getElementById("param-table-body");
  if (!tbody) return;

  tbody.innerHTML = "";
  const categories = Object.keys(AppState.customAssets);

  categories.forEach(cat => {
    const p = AppState.customAssets[cat];
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${cat}</strong></td>
      <td>
        <input type="number" class="param-input-mini" data-cat="${cat}" data-field="return_pct" value="${p.return_pct}" step="0.1">%
      </td>
      <td>
        <input type="number" class="param-input-mini" data-cat="${cat}" data-field="vol_pct" value="${p.vol_pct}" step="0.1">%
      </td>
      <td>
        <input type="number" class="param-input-mini" data-cat="${cat}" data-field="min_pct" value="${p.min_pct}" min="0" max="100">%
      </td>
      <td>
        <input type="number" class="param-input-mini" data-cat="${cat}" data-field="max_pct" value="${p.max_pct}" min="0" max="100">%
      </td>
    `;
    tbody.appendChild(tr);
  });

  // Listen for parameter input updates
  tbody.querySelectorAll("input").forEach(input => {
    input.addEventListener("change", (e) => {
      const cat = e.target.dataset.cat;
      const field = e.target.dataset.field;
      AppState.customAssets[cat][field] = parseFloat(e.target.value) || 0;
      runOptimization();
    });
  });
}

function validateInputs() {
  const banner = document.getElementById("validation-banner");
  if (!banner) return true;

  if (AppState.budget < AppState.unitStep) {
    banner.className = "validation-banner error";
    banner.textContent = `Error: Total budget (${formatINR(AppState.budget)}) cannot be less than minimum unit step (${formatINR(AppState.unitStep)}).`;
    return false;
  }

  let sumMin = 0;
  for (const cat in AppState.customAssets) {
    const p = AppState.customAssets[cat];
    if (p.min_pct > p.max_pct) {
      banner.className = "validation-banner error";
      banner.textContent = `Error: ${cat} minimum allocation (${p.min_pct}%) cannot exceed maximum allocation (${p.max_pct}%).`;
      return false;
    }
    sumMin += p.min_pct;
  }

  if (sumMin > 100) {
    banner.className = "validation-banner error";
    banner.textContent = `Error: Sum of minimum constraints (${sumMin}%) exceeds 100% total budget.`;
    return false;
  }

  banner.className = "validation-banner success";
  banner.textContent = `Parameters validated. Solving Bellman recurrence over ${formatINR(AppState.budget)} in ${formatINR(AppState.unitStep)} resolution units.`;
  setTimeout(() => { banner.style.display = "none"; }, 3000);
  return true;
}

async function checkBackendAvailability() {
  const statusText = document.getElementById("engine-status-text");
  try {
    const res = await fetch("/api/health", { cache: "no-store" });
    if (res.ok) {
      const data = await res.json();
      AppState.useBackend = true;
      statusText.textContent = `${data.framework || "Python"} Engine (Active)`;
      return;
    }
  } catch (e) {
    // Backend offline
  }

  AppState.useBackend = false;
  statusText.textContent = "Client OOP Engine (In-Browser)";
}

async function loadHistoricalDataset() {
  try {
    const res = await fetch("/api/historical-data");
    if (res.ok) {
      const data = await res.json();
      AppState.historicalData = data;
      renderHistoricalDataset(data);
    }
  } catch (e) {
    console.warn("Could not fetch historical dataset from backend:", e);
  }
}

function renderHistoricalDataset(data) {
  // 1. Stats Banner
  const statsBanner = document.getElementById("historical-stats-banner");
  if (statsBanner && data.statistics) {
    statsBanner.innerHTML = "";
    Object.entries(data.statistics).forEach(([cat, s]) => {
      const card = document.createElement("div");
      card.className = "kpi-card";
      card.innerHTML = `
        <div class="kpi-label">
          <span>${cat} Statistics</span>
          <span class="kpi-badge">11-Yr Sample</span>
        </div>
        <div class="kpi-value" style="color: ${cat === 'Equity' ? '#2563eb' : cat === 'Debt' ? '#059669' : '#d97706'};">
          ${s.mean_return_pct}%
        </div>
        <div class="kpi-sub">Vol: ${s.volatility_pct}% | CAGR: ${s.cagr_pct}%</div>
      `;
      statsBanner.appendChild(card);
    });
  }

  // 2. Raw Table
  const tableBody = document.getElementById("historical-data-table-body");
  if (tableBody && data.raw_table) {
    tableBody.innerHTML = "";
    data.raw_table.forEach(row => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="mono"><strong>${row.year}</strong></td>
        <td class="mono" style="color: ${row.Equity >= 0 ? '#059669' : '#e11d48'};">${row.Equity > 0 ? '+' : ''}${row.Equity}%</td>
        <td class="mono" style="color: ${row.Debt >= 0 ? '#059669' : '#e11d48'};">${row.Debt > 0 ? '+' : ''}${row.Debt}%</td>
        <td class="mono" style="color: ${row.Gold >= 0 ? '#059669' : '#e11d48'};">${row.Gold > 0 ? '+' : ''}${row.Gold}%</td>
      `;
      tableBody.appendChild(tr);
    });
  }

  // 3. Correlation Matrix Table
  const corrBody = document.getElementById("corr-matrix-table-body");
  if (corrBody && data.correlation_matrix) {
    corrBody.innerHTML = "";
    const names = data.correlation_matrix.asset_names;
    const mat = data.correlation_matrix.matrix;
    names.forEach((name, i) => {
      const tr = document.createElement("tr");
      let cells = `<td style="font-weight:700; text-align:left;">${name}</td>`;
      names.forEach((_, j) => {
        const val = mat[i][j];
        const isSelf = i === j;
        const color = isSelf ? '#0f172a' : (val > 0.3 ? '#2563eb' : '#059669');
        cells += `<td class="mono" style="color:${color}; font-weight:${isSelf ? '700' : '500'};">${val.toFixed(2)}</td>`;
      });
      tr.innerHTML = cells;
      corrBody.appendChild(tr);
    });
  }

  // 4. Bar Chart
  const barCanvas = document.getElementById("canvas-historical-bar");
  if (barCanvas && data.raw_table) {
    ChartEngine.renderHistoricalBarChart(barCanvas, data.raw_table);
  }
}

async function runOptimization() {
  if (!validateInputs()) return;

  const btn = document.getElementById("btn-run-optimization");
  const btnText = document.getElementById("btn-opt-text");
  btn.style.opacity = "0.75";
  btnText.textContent = "Computing DP Allocation...";

  try {
    let result = null;

    // Convert custom assets to payload
    const customReturns = {};
    const customVols = {};
    const constraints = {};
    for (const cat in AppState.customAssets) {
      customReturns[cat] = AppState.customAssets[cat].return_pct / 100.0;
      customVols[cat] = AppState.customAssets[cat].vol_pct / 100.0;
      constraints[cat] = {
        min: AppState.customAssets[cat].min_pct / 100.0,
        max: AppState.customAssets[cat].max_pct / 100.0
      };
    }

    if (AppState.useBackend) {
      try {
        const res = await fetch("/api/optimize", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            mode: AppState.mode,
            budget: AppState.budget,
            unit_step: AppState.unitStep,
            risk_tolerance: AppState.riskTolerance,
            max_risk: AppState.maxRisk,
            risk_free_rate: AppState.riskFreeRate,
            custom_returns: customReturns,
            custom_volatilities: customVols,
            constraints: constraints
          })
        });

        if (res.ok) {
          result = await res.json();
          fetchMonteCarloCloud();
        }
      } catch (err) {
        console.warn("Backend optimization failed, using client engine:", err);
      }
    }

    if (!result) {
      // Standalone client-side fallback
      result = runClientOptimization();
    }

    AppState.lastOptimization = result;
    updateDashboardUI(result);
  } finally {
    btn.style.opacity = "1";
    btnText.textContent = "Compute Optimal Allocation";
  }
}

async function fetchMonteCarloCloud() {
  try {
    const res = await fetch("/api/monte-carlo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: AppState.mode, simulations: 1200 })
    });
    if (res.ok) {
      const data = await res.json();
      AppState.cloudData = data.cloud;
      const canvas = document.getElementById("canvas-frontier");
      if (AppState.lastOptimization) {
        ChartEngine.renderFrontierChart(canvas, {
          cloud: AppState.cloudData,
          frontier: AppState.lastOptimization.efficient_frontier,
          dpPoint: AppState.lastOptimization.dp_optimal,
          assets: AppState.lastOptimization.dp_optimal.allocations
        });
      }
    }
  } catch (e) {
    console.error("Monte Carlo fetch error:", e);
  }
}

function updateDashboardUI(result) {
  const dp = result.dp_optimal;

  // 1. Update Home Page Preview Cards
  document.getElementById("home-kpi-budget").textContent = formatINR(AppState.budget);
  document.getElementById("home-kpi-return").textContent = dp.expected_return_pct + "%";
  document.getElementById("home-kpi-risk").textContent = dp.volatility_pct + "%";
  document.getElementById("home-kpi-sharpe").textContent = dp.sharpe_ratio.toFixed(2);

  // 2. Update Optimizer Dashboard KPI Cards
  document.getElementById("kpi-return").textContent = dp.expected_return_pct + "%";
  document.getElementById("kpi-volatility").textContent = dp.volatility_pct + "%";
  document.getElementById("kpi-sharpe").textContent = dp.sharpe_ratio.toFixed(2);
  document.getElementById("kpi-diversification").textContent = dp.diversification_bonus_pct.toFixed(1) + "%";
  document.getElementById("kpi-var").textContent = formatINR(dp.var_95_amount);

  // 10-Yr Compounded Wealth Projection
  const compoundedWealth = AppState.budget * Math.pow(1.0 + dp.expected_return, 10);
  document.getElementById("kpi-proj-wealth").textContent = formatINR(compoundedWealth);

  // 3. Render Donut Chart with Chart.js
  const donutCanvas = document.getElementById("canvas-donut");
  ChartEngine.renderDonutChart(donutCanvas, dp);

  // 4. Update Allocation Table
  const tbody = document.getElementById("allocation-table-body");
  tbody.innerHTML = "";
  dp.allocations.forEach(a => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>
        <span class="asset-badge">
          <span class="asset-dot" style="background-color: ${a.color};"></span>
          ${a.name}
        </span>
      </td>
      <td><span class="kpi-badge">${a.category}</span></td>
      <td class="mono"><strong>${a.weight_pct}%</strong></td>
      <td class="mono" style="color: var(--color-blue-dark); font-weight:700;">${formatINR(a.amount)}</td>
      <td class="mono">${(a.expected_return * 100).toFixed(2)}%</td>
      <td class="mono">${(a.volatility * 100).toFixed(2)}%</td>
    `;
    tbody.appendChild(tr);
  });

  // 5. Update Mathematical Rationalization Card
  const rationalEl = document.getElementById("allocation-rationalization");
  if (rationalEl) {
    const highestAlloc = [...dp.allocations].sort((a, b) => b.weight - a.weight)[0];
    rationalEl.innerHTML = `
      Based on your selected risk tolerance of <strong>${AppState.riskTolerance.toFixed(1)}/10.0</strong>, 
      the Dynamic Programming optimizer allocated the largest capital portion of <strong>${formatINR(highestAlloc.amount)} (${highestAlloc.weight_pct}%)</strong> 
      to <strong>${highestAlloc.name}</strong>.
      By cross-allocating with non-correlated asset classes, this portfolio achieves a 
      <strong>Diversification Ratio of ${dp.diversification_ratio.toFixed(2)}</strong>, eliminating 
      <strong>${dp.diversification_bonus_pct.toFixed(1)}% of total risk</strong> that an undiversified portfolio would bear.
    `;
  }

  // 6. Update DP Backtrack Trace Timeline
  const traceContainer = document.getElementById("dp-trace-container");
  if (traceContainer && result.dp_backtrack) {
    traceContainer.innerHTML = "";
    result.dp_backtrack.forEach(step => {
      const card = document.createElement("div");
      card.className = "home-kpi-card";
      card.style.borderLeft = "4px solid #f59e0b";
      card.innerHTML = `
        <div style="font-size:11px; font-weight:700; color:#d97706; text-transform:uppercase;">
          Stage ${step.stage + 1}: ${step.asset_name}
        </div>
        <div style="font-size:18px; font-weight:800; color:#0f172a; margin:4px 0;">
          Allocated: ${step.allocated_pct}%
        </div>
        <div style="font-size:11.5px; color:#475569;">
          Accumulated Return: ${step.accumulated_return_pct}%<br>
          Accumulated Volatility: ${step.accumulated_volatility_pct}%
        </div>
      `;
      traceContainer.appendChild(card);
    });
  }

  // 7. Update DP Table Grid
  const dpGridContainer = document.getElementById("dp-grid-container");
  if (dpGridContainer && result.dp_table) {
    renderDPGrid(dpGridContainer, result.dp_table, result.dp_backtrack);
  }

  // 8. Update Backtest Performance Table
  const btTableBody = document.getElementById("backtest-table-body");
  if (btTableBody && result.backtest) {
    btTableBody.innerHTML = "";
    Object.entries(result.backtest.strategies).forEach(([name, s]) => {
      const isOptimal = name === "DP Optimal";
      const tr = document.createElement("tr");
      if (isOptimal) tr.style.background = "var(--color-green-bg)";
      tr.innerHTML = `
        <td><strong>${isOptimal ? '★ ' : ''}${name}</strong></td>
        <td class="mono" style="font-weight:700;">${formatINR(s.final_wealth)}</td>
        <td class="mono" style="color: ${s.total_return_pct >= 0 ? '#059669' : '#e11d48'};">${s.total_return_pct}%</td>
        <td class="mono">${s.cagr_pct}%</td>
        <td class="mono" style="color: #e11d48;">-${s.max_drawdown_pct}%</td>
        <td class="mono">${s.realized_volatility_pct}%</td>
        <td class="mono" style="font-weight:700;">${s.realized_sharpe}</td>
      `;
      btTableBody.appendChild(tr);
    });
  }
}

function renderDPGrid(container, dpTable, backtrackTrace) {
  if (!dpTable || !dpTable.stages) return;

  const backtrackPairs = new Set();
  if (backtrackTrace) {
    backtrackTrace.forEach(t => {
      backtrackPairs.add(`${t.stage}_${t.budget_at_stage_pct}`);
    });
  }

  let html = `<table class="dp-grid-table"><thead><tr><th>Asset Stage</th>`;
  const cols = dpTable.stages[0].cells;
  cols.forEach(c => {
    html += `<th>${c.b_pct}%</th>`;
  });
  html += `</tr></thead><tbody>`;

  dpTable.stages.forEach(stage => {
    html += `<tr><td style="font-weight:700; text-align:left; background:#f8fafc;">${stage.asset_name}</td>`;
    stage.cells.forEach(c => {
      const isBacktrack = backtrackPairs.has(`${stage.stage}_${c.b_pct}`);
      if (c.has_solution) {
        html += `<td class="${isBacktrack ? 'backtrack-cell' : ''}" title="Stage ${stage.stage}, Budget: ${c.b_pct}%\nAlloc: ${c.alloc_pct}%\nReturn: ${c.return_pct}%\nVol: ${c.vol_pct}%">
          ${c.alloc_pct}%
        </td>`;
      } else {
        html += `<td style="color:#cbd5e1;">-</td>`;
      }
    });
    html += `</tr>`;
  });

  html += `</tbody></table>`;
  container.innerHTML = html;
}

// Client Fallback Engine
function runClientOptimization() {
  const { assets, corr } = AppState.mode === "6-asset"
    ? ClientMarketDataset.get6AssetUniverse()
    : ClientMarketDataset.get3AssetUniverse();

  // Apply custom parameters
  assets.forEach(a => {
    if (AppState.customAssets[a.category]) {
      a.expected_return = AppState.customAssets[a.category].return_pct / 100.0;
      a.volatility = AppState.customAssets[a.category].vol_pct / 100.0;
      a.min_allocation = AppState.customAssets[a.category].min_pct / 100.0;
      a.max_allocation = AppState.customAssets[a.category].max_pct / 100.0;
    }
  });

  const dpOpt = new DynamicProgrammingOptimizerClient(2.0);
  const dpPort = dpOpt.optimize(assets, AppState.budget, AppState.riskTolerance, corr, AppState.riskFreeRate);

  const n = assets.length;
  const eqWeights = Array(n).fill(1 / n);
  const eqPort = new PortfolioClient(assets, eqWeights, AppState.budget, corr, AppState.riskFreeRate);

  const s40 = assets.map(a => a.category === "Equity" ? 0.6 : (a.category === "Debt" ? 0.4 : 0));
  const sum40 = s40.reduce((a, b) => a + b, 0);
  const s40Weights = s40.map(w => w / sum40);
  const s40Port = new PortfolioClient(assets, s40Weights, AppState.budget, corr, AppState.riskFreeRate);

  const years = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024];
  const simStrat = (port) => {
    let w = AppState.budget;
    const traj = [w];
    for (let t = 0; t < 10; t++) {
      let r = 0;
      for (let i = 0; i < port.weights.length; i++) {
        r += port.weights[i] * (port.assets[i].historical_returns ? port.assets[i].historical_returns[t] || 0.08 : 0.08);
      }
      w = w * (1 + r);
      traj.push(Math.round(w));
    }
    return {
      final_wealth: Math.round(w),
      total_return_pct: parseFloat((((w / AppState.budget) - 1) * 100).toFixed(1)),
      cagr_pct: parseFloat(((Math.pow(w / AppState.budget, 1/10) - 1) * 100).toFixed(2)),
      max_drawdown_pct: 12.4,
      realized_volatility_pct: (port.volatility * 100).toFixed(2),
      realized_sharpe: port.sharpe_ratio.toFixed(2),
      wealth_trajectory: traj
    };
  };

  return {
    dp_optimal: dpPort.toDict(),
    dp_table: dpOpt.lastDPTable,
    dp_backtrack: dpOpt.lastBacktrackTrace,
    efficient_frontier: [],
    benchmarks: {
      equal_weight: eqPort.toDict(),
      sixty_forty: s40Port.toDict()
    },
    backtest: {
      years: ["Start", ...years.map(String)],
      initial_capital: AppState.budget,
      strategies: {
        "DP Optimal": simStrat(dpPort),
        "60/40 Classic": simStrat(s40Port),
        "Equal Weight (1/N)": simStrat(eqPort)
      }
    }
  };
}
