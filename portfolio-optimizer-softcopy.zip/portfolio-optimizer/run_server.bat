@echo off
title Investment Portfolio Diversification Optimizer Server
echo ======================================================================
echo  Investment Portfolio Diversification Optimizer
echo  Quantitative Bellman DP • Modern Portfolio Theory • Simulation
echo ======================================================================
echo.
echo Starting Web Server on http://localhost:8000 ...
echo (Supports both Flask and Zero-Dependency Standard Library HTTP Server)
echo.
python app.py 8000
pause
