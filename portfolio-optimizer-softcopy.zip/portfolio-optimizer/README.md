# Investment Portfolio Diversification Optimizer

An interactive quantitative finance simulation, discrete optimization, and educational web platform that applies **Dynamic Programming (Bellman's Principle of Optimality)** and **Modern Portfolio Theory (Harry Markowitz)** to allocate a fixed investment budget across multi-asset categories (**Equity**, **Debt**, and **Gold**).

Engineered with clean **Object-Oriented Programming (OOP)**, **Flask**, **Pandas**, **NumPy**, and **Chart.js** to help students, investors, and finance practitioners understand portfolio construction, risk-return tradeoffs, covariance-driven diversification, and discrete resource allocation algorithms.

---

## 🌟 Key Highlights & Features

1. **Dynamic Programming Asset Allocation**:
   - Discretizes investment capital $B$ in Indian Rupees (₹) into quantized resolution steps (e.g., ₹1,000 or ₹5,000 units).
   - Recursively solves the bounded multi-asset resource allocation problem:
     $$V(i, b) = \max_{\text{min}_i \le x_i \le \min(\text{max}_i, b)} \left\{ U(x_i) + V(i-1, b - x_i) \right\}$$
   - Generates an interactive **2D DP Memoization Matrix** exposing subproblem optimal substructure, state transitions, and the amber-highlighted backtracking decision path.
   - Enforces optional **Maximum Acceptable Portfolio Risk** ceilings and asset-level percentage bounds.

2. **Object-Oriented Programming (OOP) Architecture**:
   - `AssetClass`: Base class encapsulating asset name, historical returns, expected returns $\mu$, annualized volatility $\sigma$, variance $\sigma^2$, and allocation constraints (`min_allocation`, `max_allocation`).
   - `EquityAsset`, `DebtAsset`, `GoldAsset`: Specialized subclasses modeling market beta, dividend yields, bond durations, credit ratings, expense ratios, and safe-haven properties.
   - `CorrelationMatrix`: Models empirical correlation coefficients $\rho_{ij}$ and computes the $N \times N$ covariance matrix $\mathbf{\Sigma}$.
   - `Portfolio`: Calculates expected return $\mathbf{w}^T \mathbf{\mu}$, portfolio variance $\mathbf{w}^T \mathbf{\Sigma} \mathbf{w}$, Sharpe ratio, 95% Parametric Value at Risk (VaR in ₹), Conditional VaR (Expected Shortfall in ₹), and the **Diversification Ratio**.
   - `PortfolioOptimizer` (aliased as `DynamicProgrammingOptimizer`): Strategy pattern implementing the Bellman dynamic programming algorithm with state memoization and backtracking.
   - `DataManager`: Handles loading CSV historical datasets (`data/historical_returns.csv`), data cleaning, missing value handling, and statistical estimation using Pandas/NumPy (with a pure Python standard library fallback).
   - `BacktestEngine`: 10-year historical compounding simulation with annual portfolio rebalancing.

3. **CSV Historical Dataset & Statistics (`data/historical_returns.csv`)**:
   - 11-year empirical annual returns (2014 – 2024) calibrated to multi-asset market benchmarks:
     - **Equity**: Broad Market Total Return Index (Mean: 15.86%, Vol: 13.50%)
     - **Debt**: 10-Year Sovereign Government Securities (Mean: 7.95%, Vol: 3.77%)
     - **Gold**: Domestic / LBMA Bullion Price (Mean: 9.92%, Vol: 12.47%)
   - Clearly labeled as demonstration data for college educational simulation, structured so real market time series can be plugged in directly.

4. **10-Year Compounding Historical Backtesting Engine**:
   - Compares DP Optimal vs. Markowitz MPT vs. 60/40 Classic vs. 100% Equity vs. Equal Weight.
   - Key metrics: Cumulative Final Wealth (₹), Total Return %, CAGR %, Maximum Drawdown (MDD) %, Realized Volatility %, and Realized Sharpe Ratio.

5. **Professional Institutional Dashboard UI**:
   - Dark navy theme with white elevated cards, high-contrast typography, emerald green highlights, and financial blue accents.
   - **Chart.js Visualizations**: Asset allocation donut chart, annual returns bar chart, continuous Markowitz efficient frontier, and 10-year backtest growth curve.
   - Responsive layout for desktop, tablet, and mobile with intuitive navigation tabs.

6. **Interactive Student Quant Sandbox & Quiz**:
   - **The "Free Lunch" Correlation Lab**: Real-time slider varying correlation $\rho \in [-1.0, +1.0]$ to witness volatility reduction without sacrificing expected return.
   - **Bellman Equation Breakdown**: Step-by-step mathematical derivation of state transitions.
   - **Interactive Knowledge Quiz**: Multiple-choice assessment with instant pedagogical feedback.

---

## 📂 Project Directory Structure

```
portfolio-optimizer/
├── app.py                    # Flask Web Application & REST API
├── server.py                 # Zero-dependency Python standard library HTTP & REST server
├── requirements.txt          # Python dependencies: Flask, pandas, numpy
├── test_engine.py            # Comprehensive 7-module unit test suite (100% passing)
├── run_server.bat            # 1-Click Windows server launcher
├── README.md                 # Complete system documentation
├── data/
│   └── historical_returns.csv # 11-year historical annual returns dataset (2014-2024)
├── engine/
│   ├── __init__.py           # Package exports (OOP classes & DataManager)
│   ├── assets.py             # OOP Hierarchy: AssetClass, EquityAsset, DebtAsset, GoldAsset, CorrelationMatrix
│   ├── portfolio.py          # Portfolio model, Sharpe, VaR, CVaR, Diversification Ratio
│   ├── strategies.py         # PortfolioOptimizer (DP), Markowitz, Monte Carlo, Equal Weight, Risk Parity
│   ├── data_manager.py       # DataManager: CSV loading, statistics, data validation, asset preparation
│   ├── backtest.py           # 10-year empirical compounding engine
│   └── dataset.py            # Calibrated baseline market universe definitions
└── static/
    ├── index.html            # Institutional FinTech single-page dashboard
    ├── css/
    │   └── style.css         # Dark navy background, white cards, green highlights, responsive CSS
    └── js/
        ├── app.js            # Main UI controller, parameter validation, REST API client
        ├── charts.js         # Chart.js + Canvas fallback rendering engine
        ├── engine-client.js  # Full client-side JavaScript OOP engine mirror
        └── educational.js    # Interactive correlation lab and student quant quiz
```

---

## 📐 Mathematical Formulation

### 1. Risk-Adjusted Mean-Variance Utility
Given an Arrow-Pratt risk aversion coefficient $\lambda \ge 0$:
$$U(\mathbf{w}) = E[R_p](\mathbf{w}) - \frac{\lambda}{2} \sigma_p^2(\mathbf{w})$$
where:
$$E[R_p](\mathbf{w}) = \sum_{i=1}^N w_i \mu_i, \quad \sigma_p^2(\mathbf{w}) = \sum_{i=1}^N \sum_{j=1}^N w_i w_j \Sigma_{ij}$$

The risk aversion coefficient $\lambda$ is parameterized from the user's risk tolerance $\gamma \in [1.0, 10.0]$:
$$\lambda(\gamma) = \frac{28.0}{\gamma^{1.3}}$$
- $\gamma = 2.0$ (Conservative): $\lambda \approx 11.4 \implies$ Heavy volatility penalty, prioritizing Debt and Gold.
- $\gamma = 5.0$ (Balanced): $\lambda \approx 3.5 \implies$ Optimal Sharpe ratio tradeoff.
- $\gamma = 8.5$ (Aggressive): $\lambda \approx 1.7 \implies$ Capital appreciation focus, heavier Equity allocation.

### 2. The Dynamic Programming State Space
Let the budget $B$ be quantized into $M = B / \Delta b$ discrete units (e.g. ₹5,000 steps).
- **Stage $i \in \{0, 1, \dots, N-1\}$**: Asset category index.
- **State $b \in \{0, 1, \dots, M\}$**: Budget units allocated across the first $i$ assets.
- **Decision $x_i \in \{0, 1, \dots, b\}$**: Units assigned to asset $i$ subject to $min\_units_i \le x_i \le max\_units_i$.
- **Recurrence**:
  $$DP[i][b] = \max_{x_i} \left\{ \text{Utility}(DP[i-1][b - x_i] \oplus x_i) \right\}$$
- **Complexity**:
  - Time Complexity: $\mathcal{O}(N \cdot M^2)$ where $M = 100$ runs in $<15\text{ ms}$.
  - Space Complexity: $\mathcal{O}(N \cdot M)$ 2D memoization table.

### 3. The Diversification "Free Lunch"
$$\text{Diversification Ratio} = \frac{\sum_{i=1}^N w_i \sigma_i}{\sigma_p}$$
When assets are imperfectly correlated ($\rho_{ij} < 1$):
$$\sigma_p < \sum_{i=1}^N w_i \sigma_i \implies \text{Diversification Ratio} > 1.0$$
$$\text{Risk Eliminated} = \left( 1 - \frac{\sigma_p}{\sum w_i \sigma_i} \right) \times 100\%$$

---

## 🚀 Quick Start Guide

### Option 1: Run with Flask (Recommended)
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Start the web application:
   ```bash
   python app.py 8000
   ```
3. Open your browser to:
   ```
   http://localhost:8000
   ```

### Option 2: Run with Zero-Dependency Server
Double-click `run_server.bat` or run:
```bash
python server.py 8000
```
Then navigate to `http://localhost:8000`.

### Option 3: Standalone Browser Launch (No server required!)
Simply open `static/index.html` directly in any modern browser:
```
file:///C:/Users/Admin/.gemini/antigravity/scratch/portfolio-optimizer/static/index.html
```
The client-side OOP mirror (`engine-client.js`) automatically executes all financial and DP calculations locally.

---

## 🧪 Running Unit Tests

Run the comprehensive unit test suite to verify mathematics, OOP inheritance, CSV parsing, and DP correctness:
```bash
python test_engine.py
```

Outputs validation across all 7 modules:
- Module 1: 3-Asset & 6-Asset Calibrated Datasets
- Module 2: Dynamic Programming Optimizer with Various Risk Profiles
- Module 3: Markowitz Efficient Frontier & Monte Carlo Simplex
- Module 4: Standard Benchmarks (Equal Weight 1/N, Risk Parity)
- Module 5: 10-Year Compounding Backtest Engine (2015–2024)
- Module 6: DataManager CSV Loader & Statistical Computations
- Module 7: PortfolioOptimizer with INR Budget, Unit Steps, Constraints & Risk Ceiling
