# engine/dataset.py
"""
Historical return and volatility datasets calibrated to empirical 10-year market data (2014-2024).
Provides both a 3-Asset primary baseline (Equity, Debt, Gold) and an expanded 6-Asset universe.
"""

from typing import List, Tuple
from .assets import AssetClass, EquityAsset, DebtAsset, GoldAsset, CorrelationMatrix


def get_default_market_dataset(mode: str = "3-asset") -> Tuple[List[AssetClass], CorrelationMatrix]:
    """
    Returns configured asset classes and corresponding correlation matrix.
    Modes:
      - '3-asset': Broad Macro categories (Equity, Debt, Gold)
      - '6-asset': Granular universe (Large Cap, Tech Growth, Govt Bonds, Corp Bonds, Physical Gold, Gold Mining ETF)
    """
    if mode == "6-asset":
        return _get_6_asset_universe()
    return _get_3_asset_universe()


def _get_3_asset_universe() -> Tuple[List[AssetClass], CorrelationMatrix]:
    # 10-year annual returns (2015 - 2024) calibrated to real asset index benchmarks:
    # Equity (Broad Market Total Return)
    equity_hist = [0.014, 0.120, 0.218, -0.044, 0.315, 0.184, 0.287, -0.181, 0.263, 0.155]
    # Debt (Barclays Aggregate Bond / 10Y Treasuries)
    debt_hist = [0.005, 0.026, 0.035, 0.000, 0.087, 0.075, -0.015, -0.130, 0.055, 0.042]
    # Gold (LBMA Gold PM USD)
    gold_hist = [-0.104, 0.081, 0.131, -0.016, 0.183, 0.251, -0.036, -0.003, 0.131, 0.182]

    equity = EquityAsset(
        name="Global Equity (Stock Market)",
        ticker="EQTY",
        expected_return=0.132,   # 13.2%
        volatility=0.175,        # 17.5%
        historical_returns=equity_hist,
        beta=1.00,
        dividend_yield=0.018,    # 1.8%
        market_cap_tier="Large Cap Blend",
        description="Represents ownership in productive corporate enterprises. Offers high long-term capital appreciation driven by earnings growth, but carries elevated market drawdown volatility.",
        color="#3b82f6"  # Blue
    )

    debt = DebtAsset(
        name="Government & Sovereign Debt (Bonds)",
        ticker="DEBT",
        expected_return=0.052,   # 5.2%
        volatility=0.062,        # 6.2%
        historical_returns=debt_hist,
        credit_rating="AAA Sovereign",
        duration_years=6.5,
        coupon_rate=0.045,       # 4.5%
        ytm=0.048,               # 4.8%
        description="Fixed-income sovereign securities with fixed coupon distributions and capital guarantee at maturity. Acts as the stabilizing bedrock to dampen equity drawdowns.",
        color="#10b981"  # Emerald
    )

    gold = GoldAsset(
        name="Precious Metals (Gold)",
        ticker="GOLD",
        expected_return=0.088,   # 8.8%
        volatility=0.135,        # 13.5%
        historical_returns=gold_hist,
        form="Physical Bullion / Sovereign ETF",
        expense_ratio=0.0025,    # 0.25%
        safe_haven_score=9.6,
        description="Historical monetary reserve and monetary hedge against fiat currency devaluation, geopolitical shocks, and stagflation. Demonstrates near-zero correlation to equities.",
        color="#f59e0b"  # Amber
    )

    assets = [equity, debt, gold]

    # Empirical correlation matrix:
    #           Equity    Debt    Gold
    # Equity    1.00     0.18    0.04
    # Debt      0.18     1.00    0.22
    # Gold      0.04     0.22    1.00
    corr_matrix = [
        [1.00, 0.18, 0.04],
        [0.18, 1.00, 0.22],
        [0.04, 0.22, 1.00]
    ]

    return assets, CorrelationMatrix([a.name for a in assets], corr_matrix)


def _get_6_asset_universe() -> Tuple[List[AssetClass], CorrelationMatrix]:
    eq_large = EquityAsset(
        name="US Large Cap Blend",
        ticker="SPY",
        expected_return=0.128,
        volatility=0.160,
        historical_returns=[0.014, 0.120, 0.218, -0.044, 0.315, 0.184, 0.287, -0.181, 0.263, 0.155],
        beta=1.00,
        dividend_yield=0.016,
        market_cap_tier="Mega/Large",
        description="Broad US blue-chip benchmark with mature cash flows.",
        color="#2563eb"
    )

    eq_tech = EquityAsset(
        name="Tech & Innovation Growth",
        ticker="QQQ",
        expected_return=0.174,
        volatility=0.235,
        historical_returns=[0.084, 0.059, 0.315, -0.010, 0.380, 0.476, 0.275, -0.326, 0.548, 0.210],
        beta=1.28,
        dividend_yield=0.006,
        market_cap_tier="High Growth",
        description="High-beta semiconductor, AI, and software compounders.",
        color="#8b5cf6"
    )

    debt_gov = DebtAsset(
        name="10-Year Treasury Bonds",
        ticker="IEF",
        expected_return=0.046,
        volatility=0.058,
        historical_returns=[0.005, 0.026, 0.035, 0.000, 0.087, 0.075, -0.015, -0.130, 0.055, 0.042],
        credit_rating="AAA Sovereign",
        duration_years=7.2,
        coupon_rate=0.042,
        ytm=0.044,
        description="Benchmark US Treasury debt backed by the US sovereign guarantee.",
        color="#059669"
    )

    debt_corp = DebtAsset(
        name="Investment-Grade Corporate Debt",
        ticker="LQD",
        expected_return=0.062,
        volatility=0.076,
        historical_returns=[-0.015, 0.062, 0.064, -0.025, 0.144, 0.099, -0.018, -0.178, 0.085, 0.051],
        credit_rating="A/BBB Corporate",
        duration_years=8.1,
        coupon_rate=0.053,
        ytm=0.057,
        description="Senior corporate debentures offering spread premium over treasuries.",
        color="#14b8a6"
    )

    gold_phys = GoldAsset(
        name="Physical Gold Bullion",
        ticker="GLD",
        expected_return=0.085,
        volatility=0.132,
        historical_returns=[-0.104, 0.081, 0.131, -0.016, 0.183, 0.251, -0.036, -0.003, 0.131, 0.182],
        form="Physical 99.9% Bars",
        expense_ratio=0.0040,
        safe_haven_score=9.8,
        description="Pure physical bullion vaulted with no corporate counterparty risk.",
        color="#f59e0b"
    )

    gold_miners = GoldAsset(
        name="Gold Mining & Royalties ETF",
        ticker="GDX",
        expected_return=0.105,
        volatility=0.245,
        historical_returns=[-0.247, 0.528, 0.111, -0.091, 0.398, 0.231, -0.095, -0.090, 0.105, 0.198],
        form="Equity Miner Exposure",
        expense_ratio=0.0051,
        safe_haven_score=6.8,
        description="Operating leverage to gold bullion spot prices with dividend yield.",
        color="#d97706"
    )

    assets = [eq_large, eq_tech, debt_gov, debt_corp, gold_phys, gold_miners]

    corr_matrix = [
        [1.00, 0.88, 0.12, 0.35, 0.03, 0.15],
        [0.88, 1.00, 0.05, 0.28, -0.02, 0.18],
        [0.12, 0.05, 1.00, 0.72, 0.24, 0.12],
        [0.35, 0.28, 0.72, 1.00, 0.18, 0.16],
        [0.03,-0.02, 0.24, 0.18, 1.00, 0.78],
        [0.15, 0.18, 0.12, 0.16, 0.78, 1.00]
    ]

    return assets, CorrelationMatrix([a.name for a in assets], corr_matrix)
