# engine/backtest.py
"""
10-Year Historical Backtest Engine (2015-2024).
Simulates annual rebalancing, cumulative wealth trajectories, maximum drawdown,
and realized Sharpe ratios across comparing investment strategies.
"""

from typing import List, Dict, Any
import math
from .assets import AssetClass
from .portfolio import Portfolio


class BacktestEngine:
    """
    Simulates multi-year portfolio performance using empirical historical returns.
    """
    def __init__(self, years: List[int] = None):
        self.years = years or [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024]

    def run_backtest(
        self,
        portfolios: Dict[str, Portfolio],
        initial_capital: float = 100000.0,
        risk_free_rate: float = 0.035
    ) -> Dict[str, Any]:
        """
        Runs historical simulation for a dictionary of named portfolios:
        e.g., {'DP Optimal': p1, 'Equal Weight': p2, '60/40 Balanced': p3, '100% Equity': p4}
        """
        results: Dict[str, Any] = {}
        n_years = len(self.years)

        for name, port in portfolios.items():
            # Check length of historical returns
            min_len = min(len(a.historical_returns) for a in port.assets)
            sim_years = min(n_years, min_len)

            wealth = initial_capital
            wealth_trajectory = [wealth]
            annual_returns = []
            peak_wealth = wealth
            max_drawdown = 0.0

            for t in range(sim_years):
                # Annual portfolio return: sum(w_i * r_{i, t})
                r_t = sum(w * a.historical_returns[t] for w, a in zip(port.weights, port.assets))
                annual_returns.append(r_t)

                # Rebalanced wealth compounding
                wealth = wealth * (1.0 + r_t)
                wealth_trajectory.append(round(wealth, 2))

                # Track drawdown
                if wealth > peak_wealth:
                    peak_wealth = wealth
                dd = (peak_wealth - wealth) / peak_wealth
                if dd > max_drawdown:
                    max_drawdown = dd

            # CAGR
            cagr = ((wealth / initial_capital) ** (1.0 / sim_years) - 1.0) if sim_years > 0 else 0.0

            # Realized Annual Volatility
            mean_r = sum(annual_returns) / sim_years if sim_years > 0 else 0.0
            var_r = sum((r - mean_r) ** 2 for r in annual_returns) / (sim_years - 1) if sim_years > 1 else 0.0
            realized_vol = math.sqrt(var_r)

            # Realized Sharpe Ratio
            realized_sharpe = (mean_r - risk_free_rate) / realized_vol if realized_vol > 1e-6 else 0.0

            results[name] = {
                "final_wealth": round(wealth, 2),
                "total_return_pct": round(((wealth / initial_capital) - 1.0) * 100, 2),
                "cagr_pct": round(cagr * 100, 2),
                "max_drawdown_pct": round(max_drawdown * 100, 2),
                "realized_volatility_pct": round(realized_vol * 100, 2),
                "realized_sharpe": round(realized_sharpe, 3),
                "wealth_trajectory": wealth_trajectory,
                "annual_returns_pct": [round(r * 100, 2) for r in annual_returns]
            }

        return {
            "years": ["Start"] + [str(y) for y in self.years[:sim_years]],
            "initial_capital": initial_capital,
            "strategies": results
        }
