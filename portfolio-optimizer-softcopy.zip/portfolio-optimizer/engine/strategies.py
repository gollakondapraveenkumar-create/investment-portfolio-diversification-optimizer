# engine/strategies.py
"""
Object-Oriented Portfolio Strategies implementing the Strategy Pattern.
Features Dynamic Programming Budget Allocation with full memoization state tracking,
alongside Markowitz Modern Portfolio Theory, Monte Carlo Simulation, and standard baselines.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Tuple, Optional
import math
import random

from .assets import AssetClass, CorrelationMatrix
from .portfolio import Portfolio


class OptimizationStrategy(ABC):
    """
    Abstract Strategy Interface for Portfolio Optimization algorithms.
    """
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description

    @abstractmethod
    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        """Execute portfolio optimization and return optimal Portfolio instance."""
        pass


class PortfolioOptimizer(OptimizationStrategy):
    """
    Dynamic Programming Portfolio Optimizer.
    Discretizes the fixed investment budget into quantized units (e.g. ₹1,000 steps or percentage units)
    and recursively finds the optimal allocation vector that maximizes risk-adjusted utility:
        U(w) = E[R_p](w) - (lambda / 2) * Var_p(w)
    subject to:
        sum(w_i) = 1.0,  min_weight_i <= w_i <= max_weight_i,  and optional max portfolio risk.
    
    Generates a full 2D DP Table [Asset_i, Budget_b] exposing subproblem optimal substructure,
    recurrence transitions, and backtrack path for student inspection.
    """
    def __init__(self, step_pct: float = 2.0, unit_step: Optional[float] = None):
        super().__init__(
            name="Portfolio Optimizer (Dynamic Programming)",
            description="Solves bounded discrete resource allocation using Bellman's principle of optimality."
        )
        self.step_pct = step_pct  # Resolution in percentage points (e.g. 2% = 50 discrete units)
        self.unit_step = unit_step  # Optional rupee unit step (e.g. 1000)
        self.last_dp_table: Optional[Dict[str, Any]] = None
        self.last_backtrack_trace: Optional[List[Dict[str, Any]]] = None

    def _risk_aversion_lambda(self, risk_tolerance: float) -> float:
        """
        Maps risk tolerance (1.0 = Ultra Conservative, 10.0 = Ultra Aggressive)
        to Arrow-Pratt risk aversion coefficient lambda:
        - Risk tolerance 1.0 -> lambda = 25.0 (heavy volatility penalty)
        - Risk tolerance 5.0 -> lambda = 5.0  (balanced Sharpe focus)
        - Risk tolerance 10.0 -> lambda = 0.5 (growth focus)
        """
        clamped = max(1.0, min(10.0, risk_tolerance))
        return 28.0 / (clamped ** 1.3)

    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        n_assets = len(assets)
        constraints = constraints or {}
        unit_step = constraints.get("unit_step", self.unit_step)

        if unit_step and unit_step > 0 and budget > 0:
            M = int(round(budget / unit_step))
            M = max(10, min(200, M))  # Keep DP matrix computationally efficient (<15ms)
            step = 100.0 / M
        else:
            step = max(1.0, min(10.0, self.step_pct))
            M = int(round(100.0 / step))  # Total discrete units (e.g. 100 / 2 = 50 units)

        risk_lambda = self._risk_aversion_lambda(risk_tolerance)
        cov_matrix = correlation_matrix.compute_covariance_matrix([a.volatility for a in assets])

        # Parse constraints (min/max weight per asset in units)
        min_weights = constraints.get("min_weights", [getattr(a, "min_allocation", 0.0) for a in assets])
        max_weights = constraints.get("max_weights", [getattr(a, "max_allocation", 1.0) for a in assets])
        max_portfolio_risk = constraints.get("max_portfolio_risk")

        min_units = [int(math.ceil(w * M)) for w in min_weights]
        max_units = [int(math.floor(w * M)) for w in max_weights]

        # DP Table:
        # dp[i][b] = { 'utility': float, 'return': float, 'volatility': float, 'alloc_units': int, 'weights': List[float] }
        # where i in [0..n_assets-1], b in [0..M]
        dp_table: List[List[Optional[Dict[str, Any]]]] = [
            [None for _ in range(M + 1)] for _ in range(n_assets)
        ]

        def compute_metrics(w_list: List[float]) -> Tuple[float, float, float]:
            """Compute expected return, volatility, and risk-adjusted utility for weight vector."""
            ret = sum(w * a.expected_return for w, a in zip(w_list, assets))
            var = 0.0
            for i in range(len(w_list)):
                for j in range(len(w_list)):
                    var += w_list[i] * w_list[j] * cov_matrix[i][j]
            vol = math.sqrt(max(0.0, var))
            utility = ret - 0.5 * risk_lambda * var

            # Enforce maximum acceptable risk ceiling if specified
            if max_portfolio_risk is not None and max_portfolio_risk > 0:
                if vol > (max_portfolio_risk + 1e-4):
                    penalty = 1e4 * (vol - max_portfolio_risk)
                    utility = -1e6 - penalty

            return ret, vol, utility

        # -------------------------------------------------------------
        # Stage 0: First Asset (Base Case)
        # -------------------------------------------------------------
        for b in range(M + 1):
            if min_units[0] <= b <= max_units[0]:
                curr_weights = [0.0] * n_assets
                curr_weights[0] = b / M
                ret, vol, util = compute_metrics(curr_weights)
                dp_table[0][b] = {
                    "utility": util,
                    "expected_return": ret,
                    "volatility": vol,
                    "alloc_units": b,
                    "alloc_pct": (b / M) * 100.0,
                    "weights": curr_weights,
                    "from_b": 0
                }

        # -------------------------------------------------------------
        # Stage 1 to N-1: Sequential Asset Allocation via Bellman Transitions
        # -------------------------------------------------------------
        for i in range(1, n_assets):
            is_last_asset = (i == n_assets - 1)

            for b in range(M + 1):
                best_cell: Optional[Dict[str, Any]] = None
                best_utility = -float("inf")

                # If this is the last asset, we MUST allocate exactly the remaining budget to reach 100% (b == M)
                # For intermediate assets, we explore valid allocations x_i
                allowed_min = min_units[i]
                allowed_max = min(max_units[i], b)

                for x in range(allowed_min, allowed_max + 1):
                    prev_b = b - x
                    prev_cell = dp_table[i - 1][prev_b]
                    if prev_cell is None:
                        continue

                    # Construct candidate weight vector combining subproblem and new decision
                    cand_weights = list(prev_cell["weights"])
                    cand_weights[i] = x / M

                    ret, vol, util = compute_metrics(cand_weights)

                    if util > best_utility:
                        best_utility = util
                        best_cell = {
                            "utility": util,
                            "expected_return": ret,
                            "volatility": vol,
                            "alloc_units": x,
                            "alloc_pct": (x / M) * 100.0,
                            "weights": cand_weights,
                            "from_b": prev_b
                        }

                dp_table[i][b] = best_cell

        # -------------------------------------------------------------
        # Backtracking & Result Extraction from dp_table[N-1][M]
        # -------------------------------------------------------------
        final_state = dp_table[n_assets - 1][M]
        if final_state is None:
            # Fallback to equal weighting if constraints were too rigid
            final_weights = [1.0 / n_assets] * n_assets
        else:
            final_weights = final_state["weights"]

        # Re-normalize to guarantee exact 1.0 sum
        total_w = sum(final_weights)
        if total_w > 0:
            final_weights = [w / total_w for w in final_weights]

        # Prepare educational backtrack trace for website visualization
        trace = []
        curr_b = M
        for i in range(n_assets - 1, -1, -1):
            cell = dp_table[i][curr_b]
            if cell:
                trace.append({
                    "stage": i,
                    "asset_name": assets[i].name,
                    "asset_ticker": assets[i].ticker,
                    "allocated_units": cell["alloc_units"],
                    "allocated_pct": round(cell["alloc_pct"], 2),
                    "accumulated_return_pct": round(cell["expected_return"] * 100, 2),
                    "accumulated_volatility_pct": round(cell["volatility"] * 100, 2),
                    "utility": round(cell["utility"], 4),
                    "budget_at_stage_pct": round((curr_b / M) * 100, 1),
                    "transition_from_budget_pct": round((cell["from_b"] / M) * 100, 1)
                })
                curr_b = cell["from_b"]
        trace.reverse()

        # Simplify DP Table representation for JSON inspection (downsampling for fast browser rendering)
        browser_dp_grid = []
        sample_stride = max(1, M // 20)  # ~20 columns in UI for clean readability
        for i in range(n_assets):
            row = []
            for b in range(0, M + 1, sample_stride):
                cell = dp_table[i][b]
                if cell:
                    row.append({
                        "b_pct": round((b / M) * 100, 1),
                        "alloc_pct": round(cell["alloc_pct"], 1),
                        "return_pct": round(cell["expected_return"] * 100, 2),
                        "vol_pct": round(cell["volatility"] * 100, 2),
                        "utility": round(cell["utility"], 4),
                        "has_solution": True
                    })
                else:
                    row.append({
                        "b_pct": round((b / M) * 100, 1),
                        "has_solution": False
                    })
            browser_dp_grid.append({
                "stage": i,
                "asset_name": assets[i].name,
                "ticker": assets[i].ticker,
                "cells": row
            })

        self.last_dp_table = {
            "num_stages": n_assets,
            "discretization_step_pct": step,
            "total_units": M,
            "risk_lambda": round(risk_lambda, 3),
            "grid": browser_dp_grid
        }
        self.last_backtrack_trace = trace

        return Portfolio(
            assets=assets,
            weights=final_weights,
            total_budget=budget,
            correlation_matrix=correlation_matrix,
            risk_free_rate=risk_free_rate
        )


class MarkowitzOptimizer(OptimizationStrategy):
    """
    Modern Portfolio Theory (Harry Markowitz) Optimizer.
    Solves for the continuous Efficient Frontier by sweeping target return levels
    and analytical/quadratic risk minimization, finding the Tangency / Max Sharpe portfolio.
    """
    def __init__(self, frontier_samples: int = 40):
        super().__init__(
            name="Markowitz Modern Portfolio Theory",
            description="Mean-Variance continuous optimization tracing the Pareto Efficient Frontier."
        )
        self.frontier_samples = frontier_samples

    def generate_efficient_frontier(
        self,
        assets: List[AssetClass],
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        num_points: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Generates the smooth Efficient Frontier curve from Minimum Variance to Maximum Return.
        Uses quadratic interpolation across convex risk-return combinations.
        """
        n = len(assets)
        cov = correlation_matrix.compute_covariance_matrix([a.volatility for a in assets])
        min_ret = min(a.expected_return for a in assets)
        max_ret = max(a.expected_return for a in assets)

        frontier_points = []
        # Sample target returns along the feasible interval
        for step in range(num_points):
            t = step / (num_points - 1)
            target_r = min_ret + t * (max_ret - min_ret)

            # Optimization search for weights that achieve target_r with minimum variance
            best_vol = float("inf")
            best_w = None

            # Dense convex grid search over simplex
            for _ in range(400):
                # Dirichlet-like random weights biased toward assets meeting target_r
                raw = [random.expovariate(1.0) for _ in range(n)]
                s = sum(raw)
                w = [r / s for r in raw]
                r_p = sum(w[i] * assets[i].expected_return for i in range(n))

                if abs(r_p - target_r) < 0.015:
                    var = 0.0
                    for i in range(n):
                        for j in range(n):
                            var += w[i] * w[j] * cov[i][j]
                    vol = math.sqrt(max(0.0, var))
                    if vol < best_vol:
                        best_vol = vol
                        best_w = w

            if best_w is not None and best_vol < float("inf"):
                sr = (target_r - risk_free_rate) / best_vol if best_vol > 0 else 0
                frontier_points.append({
                    "expected_return_pct": round(target_r * 100, 2),
                    "volatility_pct": round(best_vol * 100, 2),
                    "sharpe_ratio": round(sr, 3),
                    "weights": [round(w, 4) for w in best_w]
                })

        # Ensure sorted monotonically by volatility
        frontier_points.sort(key=lambda p: p["volatility_pct"])
        return frontier_points

    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        """
        Selects portfolio on Efficient Frontier corresponding to user's risk tolerance.
        """
        frontier = self.generate_efficient_frontier(assets, correlation_matrix, risk_free_rate, 40)
        if not frontier:
            # Fallback
            return Portfolio(assets, [1.0 / len(assets)] * len(assets), budget, correlation_matrix, risk_free_rate)

        # Scale index according to risk tolerance [1.0 to 10.0]
        # 1.0 -> Minimum Variance (index 0)
        # 10.0 -> Maximum Return (last index)
        frac = (risk_tolerance - 1.0) / 9.0
        idx = int(round(frac * (len(frontier) - 1)))
        idx = max(0, min(len(frontier) - 1, idx))

        selected_weights = frontier[idx]["weights"]
        return Portfolio(assets, selected_weights, budget, correlation_matrix, risk_free_rate)


class MonteCarloOptimizer(OptimizationStrategy):
    """
    Monte Carlo Simulation Strategy.
    Generates thousands of randomized portfolio weight vectors uniformly sampled
    over the unit simplex, creating the Risk-Return scatter cloud.
    """
    def __init__(self, num_simulations: int = 2500):
        super().__init__(
            name="Monte Carlo Simplex Simulator",
            description="Stochastic simulation of thousands of feasible allocations mapping the risk-return landscape."
        )
        self.num_simulations = num_simulations

    def generate_simulation_cloud(
        self,
        assets: List[AssetClass],
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        n_points: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Generates scatter data points with (volatility, return, Sharpe)."""
        sim_count = n_points or self.num_simulations
        n = len(assets)
        cov = correlation_matrix.compute_covariance_matrix([a.volatility for a in assets])
        cloud = []

        for _ in range(sim_count):
            # Sample uniformly from Dirichlet simplex
            raw = [random.expovariate(1.0) for _ in range(n)]
            s = sum(raw)
            w = [r / s for r in raw]

            ret = sum(w[i] * assets[i].expected_return for i in range(n))
            var = 0.0
            for i in range(n):
                for j in range(n):
                    var += w[i] * w[j] * cov[i][j]
            vol = math.sqrt(max(0.0, var))
            sr = (ret - risk_free_rate) / vol if vol > 1e-6 else 0.0

            cloud.append({
                "volatility_pct": round(vol * 100, 2),
                "expected_return_pct": round(ret * 100, 2),
                "sharpe_ratio": round(sr, 3),
                "weights": [round(x, 3) for x in w]
            })

        return cloud

    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        cloud = self.generate_simulation_cloud(assets, correlation_matrix, risk_free_rate, self.num_simulations)
        # Select best portfolio based on risk tolerance
        # Higher tolerance -> higher return focus; lower tolerance -> higher Sharpe or lower vol
        target_vol_max = 0.06 + (risk_tolerance / 10.0) * 0.14
        feasible = [p for p in cloud if (p["volatility_pct"] / 100.0) <= target_vol_max]
        if not feasible:
            feasible = cloud

        best = max(feasible, key=lambda p: p["expected_return_pct"])
        return Portfolio(assets, best["weights"], budget, correlation_matrix, risk_free_rate)


class EqualWeightStrategy(OptimizationStrategy):
    """
    Equal Weight (1/N) Benchmark.
    Allocates 1/N to each asset regardless of expected return or covariance.
    """
    def __init__(self):
        super().__init__(
            name="Equal Weight (1/N) Benchmark",
            description="Naive benchmark strategy allocating equal capital proportion to every asset category."
        )

    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        n = len(assets)
        weights = [1.0 / n] * n
        return Portfolio(assets, weights, budget, correlation_matrix, risk_free_rate)


class RiskParityStrategy(OptimizationStrategy):
    """
    Risk Parity (Inverse Volatility) Strategy.
    Weights each asset inversely proportional to its individual volatility:
        w_i proportional to (1 / sigma_i)
    Ensures lower-volatility assets receive larger capital allocations.
    """
    def __init__(self):
        super().__init__(
            name="Risk Parity / Inverse Volatility",
            description="Allocates capital inversely proportional to standalone volatility to equalize risk contribution."
        )

    def optimize(
        self,
        assets: List[AssetClass],
        budget: float,
        risk_tolerance: float,
        correlation_matrix: CorrelationMatrix,
        risk_free_rate: float = 0.035,
        constraints: Optional[Dict[str, Any]] = None
    ) -> Portfolio:
        inv_vols = [1.0 / max(1e-4, a.volatility) for a in assets]
        total_inv = sum(inv_vols)
        weights = [iv / total_inv for iv in inv_vols]
        return Portfolio(assets, weights, budget, correlation_matrix, risk_free_rate)


# DynamicProgrammingOptimizer alias for backwards compatibility and clarity
DynamicProgrammingOptimizer = PortfolioOptimizer
