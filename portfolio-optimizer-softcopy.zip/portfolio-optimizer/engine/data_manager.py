# engine/data_manager.py
"""
Historical Data Management Module for Portfolio Optimizer.
Loads CSV time series, validates historical return data, handles missing values,
and calculates statistical properties (mean returns, annualized volatilities,
and empirical covariance/correlation matrices) using Pandas/NumPy with
a zero-dependency standard library fallback.
"""

import os
import math
import csv
from typing import List, Dict, Any, Tuple, Optional

# Optional Pandas & NumPy import with automatic fallback
try:
    import pandas as pd
    import numpy as np
    HAS_PANDAS_NUMPY = True
except ImportError:
    HAS_PANDAS_NUMPY = False

from .assets import AssetClass, EquityAsset, DebtAsset, GoldAsset, CorrelationMatrix


class DataManager:
    """
    Manages loading, cleaning, statistical analysis, and preparation
    of historical multi-asset market datasets for the optimization algorithms.
    """

    DEFAULT_CSV_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "data",
        "historical_returns.csv"
    )

    def __init__(self, csv_path: Optional[str] = None):
        self.csv_path = csv_path or self.DEFAULT_CSV_PATH
        self.raw_data: List[Dict[str, Any]] = []
        self.years: List[int] = []
        self.returns_by_asset: Dict[str, List[float]] = {
            "Equity": [],
            "Debt": [],
            "Gold": []
        }
        self.statistics: Dict[str, Dict[str, float]] = {}
        self.correlation_matrix: Optional[CorrelationMatrix] = None
        self.is_illustrative: bool = True
        self.load_and_process()

    def load_csv(self, filepath: Optional[str] = None) -> bool:
        """
        Loads CSV historical data from the specified path.
        Supports comment lines (starting with #) and handles CSV formatting.
        """
        target_path = filepath or self.csv_path
        if not os.path.exists(target_path):
            raise FileNotFoundError(f"Historical returns dataset not found at: {target_path}")

        cleaned_rows = []

        if HAS_PANDAS_NUMPY:
            try:
                # Read CSV while skipping comment lines
                df = pd.read_csv(target_path, comment="#")
                # Strip column whitespace
                df.columns = [c.strip() for c in df.columns]
                # Drop rows where all elements are NaN
                df = df.dropna(how="all")
                # Convert DataFrame records to list of dicts
                for _, row in df.iterrows():
                    cleaned_rows.append(row.to_dict())
            except Exception as e:
                # Fallback to standard csv reader if pandas throws parsing error
                cleaned_rows = self._read_csv_builtin(target_path)
        else:
            cleaned_rows = self._read_csv_builtin(target_path)

        self.raw_data = cleaned_rows
        return len(self.raw_data) > 0

    def _read_csv_builtin(self, filepath: str) -> List[Dict[str, Any]]:
        """Zero-dependency fallback reader using Python's built-in csv module."""
        rows = []
        with open(filepath, mode="r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip() and not line.strip().startswith("#")]
            if not lines:
                return []
            reader = csv.DictReader(lines)
            for row in reader:
                clean_row = {}
                for k, v in row.items():
                    if k is not None:
                        clean_row[k.strip()] = v.strip() if isinstance(v, str) else v
                rows.append(clean_row)
        return rows

    def validate_and_clean_data(self) -> None:
        """
        Validates the parsed rows, handles missing or invalid numeric values,
        and organizes returns by asset category.
        """
        if not self.raw_data:
            raise ValueError("No historical data available to validate.")

        valid_years: List[int] = []
        asset_returns: Dict[str, List[float]] = {
            "Equity": [],
            "Debt": [],
            "Gold": []
        }

        required_assets = ["Equity", "Debt", "Gold"]

        for idx, row in enumerate(self.raw_data):
            try:
                year_val = int(float(row.get("Year", 2000 + idx)))
            except (ValueError, TypeError):
                year_val = 2000 + idx

            row_valid = True
            row_floats = {}

            for asset in required_assets:
                val = row.get(asset)
                if val is None or val == "" or str(val).lower() == "nan":
                    # Handle missing data: fill with 0.0 or skip
                    row_valid = False
                    break
                try:
                    num_val = float(val)
                    if math.isnan(num_val) or math.isinf(num_val):
                        row_valid = False
                        break
                    row_floats[asset] = num_val
                except (ValueError, TypeError):
                    row_valid = False
                    break

            if row_valid:
                valid_years.append(year_val)
                for asset in required_assets:
                    asset_returns[asset].append(row_floats[asset])

        if len(valid_years) < 2:
            raise ValueError(f"Insufficient valid historical data points ({len(valid_years)}). Need >= 2 years.")

        self.years = valid_years
        self.returns_by_asset = asset_returns

    def calculate_statistics(self) -> Dict[str, Dict[str, float]]:
        """
        Calculates arithmetic mean annual returns, sample volatilities (std dev),
        and min/max returns for each asset category.
        Uses Pandas/NumPy when available, otherwise standard statistical formulas.
        """
        stats: Dict[str, Dict[str, float]] = {}

        for asset, returns in self.returns_by_asset.items():
            n = len(returns)
            if n < 2:
                continue

            if HAS_PANDAS_NUMPY:
                arr = np.array(returns)
                mean_val = float(np.mean(arr))
                vol_val = float(np.std(arr, ddof=1))  # Sample standard deviation
                min_val = float(np.min(arr))
                max_val = float(np.max(arr))
            else:
                mean_val = sum(returns) / n
                variance = sum((r - mean_val) ** 2 for r in returns) / (n - 1)
                vol_val = math.sqrt(max(0.0, variance))
                min_val = min(returns)
                max_val = max(returns)

            # Compound Annual Growth Rate (CAGR) from return series
            wealth = 1.0
            for r in returns:
                wealth *= (1.0 + r)
            cagr = (wealth ** (1.0 / n)) - 1.0 if wealth > 0 else 0.0

            stats[asset] = {
                "mean_return": round(mean_val, 4),
                "mean_return_pct": round(mean_val * 100, 2),
                "volatility": round(vol_val, 4),
                "volatility_pct": round(vol_val * 100, 2),
                "cagr": round(cagr, 4),
                "cagr_pct": round(cagr * 100, 2),
                "min_return_pct": round(min_val * 100, 2),
                "max_return_pct": round(max_val * 100, 2),
                "count": n
            }

        self.statistics = stats
        return stats

    def calculate_correlation_matrix(self) -> CorrelationMatrix:
        """
        Calculates the Pearson correlation matrix across asset return series.
        """
        asset_keys = ["Equity", "Debt", "Gold"]
        n_assets = len(asset_keys)
        n_obs = len(self.years)

        matrix = [[1.0 for _ in range(n_assets)] for _ in range(n_assets)]

        if HAS_PANDAS_NUMPY:
            data_matrix = np.array([self.returns_by_asset[k] for k in asset_keys])
            corr_np = np.corrcoef(data_matrix)
            for i in range(n_assets):
                for j in range(n_assets):
                    matrix[i][j] = round(float(corr_np[i, j]), 4)
        else:
            # Standard Pearson correlation calculation
            for i in range(n_assets):
                for j in range(n_assets):
                    if i == j:
                        matrix[i][j] = 1.0
                    else:
                        xs = self.returns_by_asset[asset_keys[i]]
                        ys = self.returns_by_asset[asset_keys[j]]
                        mean_x = self.statistics[asset_keys[i]]["mean_return"]
                        mean_y = self.statistics[asset_keys[j]]["mean_return"]

                        cov = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / (n_obs - 1)
                        sx = self.statistics[asset_keys[i]]["volatility"]
                        sy = self.statistics[asset_keys[j]]["volatility"]

                        corr = cov / (sx * sy) if (sx * sy) > 1e-8 else 0.0
                        matrix[i][j] = round(max(-1.0, min(1.0, corr)), 4)

        self.correlation_matrix = CorrelationMatrix(asset_keys, matrix)
        return self.correlation_matrix

    def load_and_process(self) -> None:
        """Pipeline to load, clean, and compute statistics."""
        self.load_csv()
        self.validate_and_clean_data()
        self.calculate_statistics()
        self.calculate_correlation_matrix()

    def prepare_assets(
        self,
        custom_returns: Optional[Dict[str, float]] = None,
        custom_volatilities: Optional[Dict[str, float]] = None,
        constraints: Optional[Dict[str, Dict[str, float]]] = None
    ) -> Tuple[List[AssetClass], CorrelationMatrix]:
        """
        Builds and configures OOP AssetClass instances (Equity, Debt, Gold)
        using calculated historical data or user-specified custom overrides.
        """
        custom_returns = custom_returns or {}
        custom_volatilities = custom_volatilities or {}
        constraints = constraints or {}

        # 1. Equity Asset
        eq_ret = float(custom_returns.get("Equity", self.statistics["Equity"]["mean_return"]))
        eq_vol = float(custom_volatilities.get("Equity", self.statistics["Equity"]["volatility"]))
        eq_c = constraints.get("Equity", {})
        eq_asset = EquityAsset(
            name="Equity (Stocks)",
            ticker="EQTY",
            expected_return=eq_ret,
            volatility=eq_vol,
            historical_returns=self.returns_by_asset["Equity"],
            beta=1.05,
            dividend_yield=0.018,
            market_cap_tier="Broad Market Index",
            description="Broad equity index representing ownership in corporate enterprises. Offers high long-term wealth compounding with higher market fluctuation.",
            color="#2563eb",
            min_allocation=float(eq_c.get("min", 0.0)),
            max_allocation=float(eq_c.get("max", 1.0))
        )

        # 2. Debt Asset
        debt_ret = float(custom_returns.get("Debt", self.statistics["Debt"]["mean_return"]))
        debt_vol = float(custom_volatilities.get("Debt", self.statistics["Debt"]["volatility"]))
        debt_c = constraints.get("Debt", {})
        debt_asset = DebtAsset(
            name="Debt (Bonds)",
            ticker="DEBT",
            expected_return=debt_ret,
            volatility=debt_vol,
            historical_returns=self.returns_by_asset["Debt"],
            credit_rating="AAA / Sovereign G-Sec",
            duration_years=6.8,
            coupon_rate=0.071,
            ytm=0.072,
            description="Fixed-income sovereign and corporate bonds. Generates predictable interest income and dampens overall portfolio volatility.",
            color="#10b981",
            min_allocation=float(debt_c.get("min", 0.0)),
            max_allocation=float(debt_c.get("max", 1.0))
        )

        # 3. Gold Asset
        gold_ret = float(custom_returns.get("Gold", self.statistics["Gold"]["mean_return"]))
        gold_vol = float(custom_volatilities.get("Gold", self.statistics["Gold"]["volatility"]))
        gold_c = constraints.get("Gold", {})
        gold_asset = GoldAsset(
            name="Gold (Precious Metal)",
            ticker="GOLD",
            expected_return=gold_ret,
            volatility=gold_vol,
            historical_returns=self.returns_by_asset["Gold"],
            form="Physical Bullion / Sovereign Gold Bond",
            expense_ratio=0.0025,
            safe_haven_score=9.5,
            description="Precious metal providing safe-haven protection, inflation hedge, and low correlation with equities.",
            color="#f59e0b",
            min_allocation=float(gold_c.get("min", 0.0)),
            max_allocation=float(gold_c.get("max", 1.0))
        )

        assets = [eq_asset, debt_asset, gold_asset]
        corr = self.correlation_matrix or self.calculate_correlation_matrix()
        return assets, corr

    def to_dict(self) -> Dict[str, Any]:
        """Serializes dataset and statistics to dictionary."""
        table_rows = []
        for i, y in enumerate(self.years):
            table_rows.append({
                "year": y,
                "Equity": round(self.returns_by_asset["Equity"][i] * 100, 2),
                "Debt": round(self.returns_by_asset["Debt"][i] * 100, 2),
                "Gold": round(self.returns_by_asset["Gold"][i] * 100, 2)
            })

        return {
            "is_illustrative": self.is_illustrative,
            "disclaimer": "Historical demonstration data calibrated to multi-asset market benchmarks for educational simulation.",
            "years": self.years,
            "statistics": self.statistics,
            "correlation_matrix": self.correlation_matrix.to_dict() if self.correlation_matrix else None,
            "raw_table": table_rows
        }
