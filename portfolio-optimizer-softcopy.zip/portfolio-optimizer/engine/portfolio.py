# engine/portfolio.py
"""
Portfolio model representing an allocation across assets, encapsulating
quantitative risk-return calculations, Modern Portfolio Theory mathematics,
and risk measures (Sharpe ratio, Diversification Ratio, Value at Risk).
"""

from typing import List, Dict, Any, Optional
import math
from .assets import AssetClass, CorrelationMatrix


class Portfolio:
    """
    Encapsulates a portfolio holding with exact weights, total budget,
    and covariance-driven risk metrics.
    """
    def __init__(
        self,
        assets: List[AssetClass],
        weights: List[float],
        total_budget: float = 100000.0,
        correlation_matrix: Optional[CorrelationMatrix] = None,
        risk_free_rate: float = 0.035
    ):
        if len(assets) != len(weights):
            raise ValueError(f"Assets ({len(assets)}) and weights ({len(weights)}) count mismatch.")

        self.assets = assets
        self.weights = [float(w) for w in weights]
        self.total_budget = float(total_budget)
        self.risk_free_rate = float(risk_free_rate)

        # Normalize weights if sum is approximately 1.0 (to guard against floating point drift)
        total_w = sum(self.weights)
        if total_w > 1e-6 and abs(total_w - 1.0) > 1e-6:
            self.weights = [w / total_w for w in self.weights]

        self.correlation_matrix = correlation_matrix
        self._covariance_matrix = self._build_covariance_matrix()

    def _build_covariance_matrix(self) -> List[List[float]]:
        n = len(self.assets)
        vols = [a.volatility for a in self.assets]
        if self.correlation_matrix:
            return self.correlation_matrix.compute_covariance_matrix(vols)
        # Default fallback: independent assets
        cov = [[0.0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            cov[i][i] = vols[i] ** 2
        return cov

    @property
    def expected_return(self) -> float:
        """Portfolio expected annual return: E[R_p] = sum(w_i * mu_i)"""
        return sum(w * a.expected_return for w, a in zip(self.weights, self.assets))

    @property
    def variance(self) -> float:
        """Portfolio variance: sigma_p^2 = w^T * Sigma * w"""
        n = len(self.assets)
        total_var = 0.0
        for i in range(n):
            for j in range(n):
                total_var += self.weights[i] * self.weights[j] * self._covariance_matrix[i][j]
        return max(0.0, total_var)

    @property
    def volatility(self) -> float:
        """Portfolio annualized standard deviation: sigma_p = sqrt(variance)"""
        return math.sqrt(self.variance)

    @property
    def sharpe_ratio(self) -> float:
        """Sharpe ratio: (E[R_p] - R_f) / sigma_p"""
        vol = self.volatility
        if vol <= 1e-6:
            return 0.0
        return (self.expected_return - self.risk_free_rate) / vol

    @property
    def weighted_average_volatility(self) -> float:
        """Theoretical undiversified risk: sum(w_i * sigma_i)"""
        return sum(w * a.volatility for w, a in zip(self.weights, self.assets))

    @property
    def diversification_ratio(self) -> float:
        """
        Diversification Ratio: sum(w_i * sigma_i) / sigma_p
        Measures the diversification 'free lunch' achieved through decorrelation.
        A ratio > 1.0 means risk is lower than the weighted average of individual risks.
        """
        vol = self.volatility
        if vol <= 1e-6:
            return 1.0
        return self.weighted_average_volatility / vol

    @property
    def diversification_bonus_pct(self) -> float:
        """Percentage of total risk eliminated through cross-asset decorrelation."""
        undiv = self.weighted_average_volatility
        if undiv <= 1e-6:
            return 0.0
        return max(0.0, (1.0 - self.volatility / undiv) * 100.0)

    def value_at_risk(self, confidence: float = 0.95, horizon_years: float = 1.0) -> float:
        """
        Parametric Value at Risk (VaR) in dollar terms at given confidence level.
        For 95% confidence, z ~ 1.6449.
        VaR = (z * sigma_p * sqrt(T) - E[R_p] * T) * Budget
        """
        z_scores = {0.90: 1.2816, 0.95: 1.6449, 0.99: 2.3263}
        z = z_scores.get(confidence, 1.6449)
        loss_pct = (z * self.volatility * math.sqrt(horizon_years)) - (self.expected_return * horizon_years)
        return max(0.0, loss_pct * self.total_budget)

    def conditional_var(self, confidence: float = 0.95, horizon_years: float = 1.0) -> float:
        """
        Conditional Value at Risk (CVaR / Expected Shortfall) in dollar terms.
        For normal distribution, ES_alpha = mu + sigma * (phi(z_alpha) / (1 - alpha))
        """
        z_scores = {0.90: 1.2816, 0.95: 1.6449, 0.99: 2.3263}
        phi_z = {0.90: 0.1755, 0.95: 0.1031, 0.99: 0.0267}  # Standard normal density at z
        z = z_scores.get(confidence, 1.6449)
        pdf = phi_z.get(confidence, 0.1031)

        tail_factor = pdf / (1.0 - confidence)
        loss_pct = (tail_factor * self.volatility * math.sqrt(horizon_years)) - (self.expected_return * horizon_years)
        return max(0.0, loss_pct * self.total_budget)

    @property
    def allocation_percentages(self) -> Dict[str, float]:
        """Allocation percentage mapped by asset name."""
        return {a.name: round(w * 100.0, 2) for w, a in zip(self.weights, self.assets)}

    @property
    def allocation_amounts(self) -> Dict[str, float]:
        """Rupee capital allocation mapped by asset name."""
        return {a.name: round(w * self.total_budget, 2) for w, a in zip(self.weights, self.assets)}

    @property
    def category_breakdown(self) -> Dict[str, Dict[str, float]]:
        """Aggregates weights and dollar allocations by broad asset category (Equity, Debt, Gold)."""
        summary: Dict[str, Dict[str, float]] = {
            "Equity": {"weight": 0.0, "amount": 0.0},
            "Debt": {"weight": 0.0, "amount": 0.0},
            "Gold": {"weight": 0.0, "amount": 0.0}
        }
        for w, a in zip(self.weights, self.assets):
            cat = a.category
            if cat not in summary:
                summary[cat] = {"weight": 0.0, "amount": 0.0}
            summary[cat]["weight"] += w
            summary[cat]["amount"] += w * self.total_budget

        for cat in summary:
            summary[cat]["weight_pct"] = round(summary[cat]["weight"] * 100, 2)
            summary[cat]["amount"] = round(summary[cat]["amount"], 2)

        return summary

    def to_dict(self) -> Dict[str, Any]:
        """Serializes portfolio analytics to dictionary."""
        allocations = []
        for w, a in zip(self.weights, self.assets):
            allocations.append({
                "name": a.name,
                "ticker": a.ticker,
                "category": a.category,
                "color": a.color,
                "weight": round(w, 4),
                "weight_pct": round(w * 100, 2),
                "amount": round(w * self.total_budget, 2),
                "expected_return": round(a.expected_return, 4),
                "volatility": round(a.volatility, 4)
            })

        return {
            "total_budget": self.total_budget,
            "expected_return": round(self.expected_return, 4),
            "expected_return_pct": round(self.expected_return * 100, 2),
            "volatility": round(self.volatility, 4),
            "volatility_pct": round(self.volatility * 100, 2),
            "variance": round(self.variance, 6),
            "sharpe_ratio": round(self.sharpe_ratio, 3),
            "undiversified_volatility_pct": round(self.weighted_average_volatility * 100, 2),
            "diversification_ratio": round(self.diversification_ratio, 3),
            "diversification_bonus_pct": round(self.diversification_bonus_pct, 2),
            "var_95_amount": round(self.value_at_risk(0.95), 2),
            "var_95_pct": round(self.value_at_risk(0.95) / self.total_budget * 100, 2),
            "cvar_95_amount": round(self.conditional_var(0.95), 2),
            "cvar_95_pct": round(self.conditional_var(0.95) / self.total_budget * 100, 2),
            "allocations": allocations,
            "category_breakdown": self.category_breakdown
        }
