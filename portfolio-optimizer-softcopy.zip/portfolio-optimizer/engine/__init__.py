# engine/__init__.py
"""
Investment Portfolio Diversification Optimizer Engine
Pedagogical Quantitative Finance and Dynamic Programming Library
"""
from .assets import AssetClass, EquityAsset, DebtAsset, GoldAsset, CorrelationMatrix
from .portfolio import Portfolio
from .strategies import (
    OptimizationStrategy,
    PortfolioOptimizer,
    DynamicProgrammingOptimizer,
    MarkowitzOptimizer,
    MonteCarloOptimizer,
    EqualWeightStrategy,
    RiskParityStrategy
)
from .backtest import BacktestEngine
from .dataset import get_default_market_dataset
from .data_manager import DataManager

__all__ = [
    "AssetClass",
    "EquityAsset",
    "DebtAsset",
    "GoldAsset",
    "CorrelationMatrix",
    "Portfolio",
    "OptimizationStrategy",
    "PortfolioOptimizer",
    "DynamicProgrammingOptimizer",
    "MarkowitzOptimizer",
    "MonteCarloOptimizer",
    "EqualWeightStrategy",
    "RiskParityStrategy",
    "BacktestEngine",
    "get_default_market_dataset",
    "DataManager"
]
