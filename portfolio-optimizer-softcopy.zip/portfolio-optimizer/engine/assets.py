# engine/assets.py
"""
Object-Oriented Asset Class Hierarchy for Quantitative Portfolio Optimization.
Models Equity, Debt, and Gold asset categories with financial properties,
historical time-series distributions, and correlation structure.
"""

from typing import List, Dict, Any, Optional
import math


class AssetClass:
    """
    Base class representing a generic investable asset class.
    Demonstrates OOP encapsulation of financial risk-return metrics.
    """
    def __init__(
        self,
        name: str,
        ticker: str,
        category: str,
        expected_return: float,
        volatility: float,
        liquidity_score: float,
        historical_returns: List[float],
        description: str,
        color: str,
        min_allocation: float = 0.0,
        max_allocation: float = 1.0
    ):
        self.name = name
        self.ticker = ticker
        self.category = category  # 'Equity', 'Debt', 'Gold'
        self.expected_return = float(expected_return)  # Annualized (e.g. 0.12 for 12%)
        self.volatility = float(volatility)            # Annualized std dev (e.g. 0.18 for 18%)
        self.liquidity_score = float(liquidity_score)  # 1.0 (ultra liquid) to 0.1 (illiquid)
        self.historical_returns = [float(r) for r in historical_returns]
        self.description = description
        self.color = color
        self.min_allocation = float(min_allocation)
        self.max_allocation = float(max_allocation)
        self._validate_constraints()

    def _validate_constraints(self) -> None:
        """Validate allocation constraints."""
        if not (0.0 <= self.min_allocation <= 1.0):
            raise ValueError(f"min_allocation must be between 0.0 and 1.0, got {self.min_allocation}")
        if not (0.0 <= self.max_allocation <= 1.0):
            raise ValueError(f"max_allocation must be between 0.0 and 1.0, got {self.max_allocation}")
        if self.min_allocation > self.max_allocation:
            raise ValueError(f"min_allocation ({self.min_allocation}) cannot exceed max_allocation ({self.max_allocation})")

    def set_constraints(self, min_alloc: float, max_alloc: float) -> None:
        """Update and validate asset allocation constraints."""
        self.min_allocation = float(min_alloc)
        self.max_allocation = float(max_alloc)
        self._validate_constraints()

    @property
    def variance(self) -> float:
        """Annualized variance sigma^2."""
        return self.volatility ** 2

    def standalone_sharpe(self, risk_free_rate: float = 0.035) -> float:
        """Standalone Sharpe ratio (excess return per unit of volatility)."""
        if self.volatility <= 1e-6:
            return 0.0
        return (self.expected_return - risk_free_rate) / self.volatility

    def to_dict(self) -> Dict[str, Any]:
        """Convert asset properties to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "ticker": self.ticker,
            "category": self.category,
            "expected_return": round(self.expected_return, 4),
            "expected_return_pct": round(self.expected_return * 100, 2),
            "volatility": round(self.volatility, 4),
            "volatility_pct": round(self.volatility * 100, 2),
            "variance": round(self.variance, 6),
            "liquidity_score": self.liquidity_score,
            "historical_returns": self.historical_returns,
            "description": self.description,
            "color": self.color,
            "min_allocation": round(self.min_allocation, 4),
            "min_allocation_pct": round(self.min_allocation * 100, 2),
            "max_allocation": round(self.max_allocation, 4),
            "max_allocation_pct": round(self.max_allocation * 100, 2),
            "class_type": self.__class__.__name__
        }


class EquityAsset(AssetClass):
    """
    Equity asset class specialization.
    Models capital appreciation, systematic beta, and dividend distributions.
    """
    def __init__(
        self,
        name: str,
        ticker: str,
        expected_return: float,
        volatility: float,
        historical_returns: List[float],
        beta: float,
        dividend_yield: float,
        market_cap_tier: str,
        description: str,
        color: str = "#3b82f6",
        min_allocation: float = 0.0,
        max_allocation: float = 1.0
    ):
        super().__init__(
            name=name,
            ticker=ticker,
            category="Equity",
            expected_return=expected_return,
            volatility=volatility,
            liquidity_score=0.95,
            historical_returns=historical_returns,
            description=description,
            color=color,
            min_allocation=min_allocation,
            max_allocation=max_allocation
        )
        self.beta = beta
        self.dividend_yield = dividend_yield
        self.market_cap_tier = market_cap_tier  # 'Large Cap', 'Mid Cap', 'Tech/Growth'

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "beta": self.beta,
            "dividend_yield": round(self.dividend_yield, 4),
            "dividend_yield_pct": round(self.dividend_yield * 100, 2),
            "market_cap_tier": self.market_cap_tier
        })
        return data


class DebtAsset(AssetClass):
    """
    Debt / Fixed-Income asset class specialization.
    Models yields, credit ratings, duration sensitivity, and regular coupon income.
    """
    def __init__(
        self,
        name: str,
        ticker: str,
        expected_return: float,
        volatility: float,
        historical_returns: List[float],
        credit_rating: str,
        duration_years: float,
        coupon_rate: float,
        ytm: float,
        description: str,
        color: str = "#10b981",
        min_allocation: float = 0.0,
        max_allocation: float = 1.0
    ):
        super().__init__(
            name=name,
            ticker=ticker,
            category="Debt",
            expected_return=expected_return,
            volatility=volatility,
            liquidity_score=0.85,
            historical_returns=historical_returns,
            description=description,
            color=color,
            min_allocation=min_allocation,
            max_allocation=max_allocation
        )
        self.credit_rating = credit_rating  # 'AAA Sovereign', 'AA Corporate', 'High Yield'
        self.duration_years = duration_years
        self.coupon_rate = coupon_rate
        self.ytm = ytm  # Yield to Maturity

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "credit_rating": self.credit_rating,
            "duration_years": self.duration_years,
            "coupon_rate": round(self.coupon_rate, 4),
            "coupon_rate_pct": round(self.coupon_rate * 100, 2),
            "ytm": round(self.ytm, 4),
            "ytm_pct": round(self.ytm * 100, 2)
        })
        return data


class GoldAsset(AssetClass):
    """
    Gold / Commodity asset class specialization.
    Models safe-haven hedging, negative equity correlation, and inflation protection.
    """
    def __init__(
        self,
        name: str,
        ticker: str,
        expected_return: float,
        volatility: float,
        historical_returns: List[float],
        form: str,
        expense_ratio: float,
        safe_haven_score: float,
        description: str,
        color: str = "#f59e0b",
        min_allocation: float = 0.0,
        max_allocation: float = 1.0
    ):
        super().__init__(
            name=name,
            ticker=ticker,
            category="Gold",
            expected_return=expected_return,
            volatility=volatility,
            liquidity_score=0.90,
            historical_returns=historical_returns,
            description=description,
            color=color,
            min_allocation=min_allocation,
            max_allocation=max_allocation
        )
        self.form = form  # 'Physical Bullion', 'Gold ETF', 'Sovereign Gold Bond'
        self.expense_ratio = expense_ratio
        self.safe_haven_score = safe_haven_score  # 1 to 10 scale

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data.update({
            "form": self.form,
            "expense_ratio": round(self.expense_ratio, 4),
            "expense_ratio_pct": round(self.expense_ratio * 100, 2),
            "safe_haven_score": self.safe_haven_score
        })
        return data


class CorrelationMatrix:
    """
    Encapsulates pairwise correlation matrix and covariance matrix calculation.
    Supports scenario stress testing (Normal, Crash, Stagflation).
    """
    def __init__(self, asset_names: List[str], matrix: List[List[float]]):
        self.asset_names = asset_names
        self.matrix = matrix  # N x N correlation matrix

    def get_correlation(self, i: int, j: int) -> float:
        if i == j:
            return 1.0
        return self.matrix[i][j]

    def compute_covariance_matrix(self, volatilities: List[float]) -> List[List[float]]:
        """
        Computes covariance matrix Sigma where Sigma_ij = rho_ij * sigma_i * sigma_j.
        """
        n = len(volatilities)
        cov = [[0.0 for _ in range(n)] for _ in range(n)]
        for i in range(n):
            for j in range(n):
                cov[i][j] = self.get_correlation(i, j) * volatilities[i] * volatilities[j]
        return cov

    def to_dict(self) -> Dict[str, Any]:
        return {
            "asset_names": self.asset_names,
            "matrix": self.matrix
        }
