# server.py
"""
Lightweight Python HTTP Server and JSON REST API for Portfolio Optimizer.
Uses standard library http.server (no external dependencies required).
Serves the web client and exposes endpoints for DP optimization, MPT, and simulation.
"""

import http.server
import socketserver
import json
import urllib.parse
import os
import sys

# Ensure engine is on path
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from engine import (
    DataManager,
    PortfolioOptimizer,
    DynamicProgrammingOptimizer,
    MarkowitzOptimizer,
    MonteCarloOptimizer,
    EqualWeightStrategy,
    RiskParityStrategy,
    BacktestEngine,
    Portfolio,
    get_default_market_dataset
)
from app import execute_optimization

PORT = 8000
STATIC_DIR = os.path.join(CURRENT_DIR, "static")
DATA_MGR = DataManager()


class PortfolioRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Handles static files and API requests."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=STATIC_DIR, **kwargs)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/api/health":
            self._send_json({"status": "ok", "app": "Investment Portfolio Diversification Optimizer", "version": "2.0.0"})
            return

        if path == "/api/historical-data":
            self._send_json(DATA_MGR.to_dict())
            return

        if path == "/api/assets":
            mode = query.get("mode", ["3-asset"])[0]
            if mode == "3-asset":
                assets, corr = DATA_MGR.prepare_assets()
            else:
                assets, corr = get_default_market_dataset(mode)
            response = {
                "mode": mode,
                "assets": [a.to_dict() for a in assets],
                "correlation_matrix": corr.to_dict()
            }
            self._send_json(response)
            return

        # Default static file handling
        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else "{}"
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            self._send_json({"error": "Invalid JSON payload"}, status=400)
            return

        if path == "/api/optimize":
            try:
                response = execute_optimization(payload, DATA_MGR)
                self._send_json(response)
            except Exception as e:
                self._send_json({"error": f"Optimization failed: {str(e)}"}, status=400)
            return

        if path == "/api/monte-carlo":
            self._handle_monte_carlo(payload)
            return

        self._send_json({"error": "Endpoint not found"}, status=404)

    def _handle_monte_carlo(self, payload):
        mode = payload.get("mode", "3-asset")
        n_points = int(payload.get("simulations", 1500))
        risk_free_rate = float(payload.get("risk_free_rate", 0.035))

        assets, corr = get_default_market_dataset(mode)
        mc = MonteCarloOptimizer(num_simulations=n_points)
        cloud = mc.generate_simulation_cloud(assets, corr, risk_free_rate, n_points)
        self._send_json({"simulations": len(cloud), "cloud": cloud})

    def _send_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()


def run(port=PORT):
    server_address = ("", port)
    # Enable socket address reuse to avoid port binding lockups on rapid restarts
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(server_address, PortfolioRequestHandler) as httpd:
        print(f"===============================================================")
        print(f" Portfolio Optimization Server Running at:")
        print(f" http://localhost:{port}")
        print(f" Serving UI from: {STATIC_DIR}")
        print(f"===============================================================")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server gracefully...")
            httpd.server_close()


if __name__ == "__main__":
    port_arg = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    run(port_arg)
