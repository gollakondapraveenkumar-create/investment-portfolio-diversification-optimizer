# test_engine.py
"""Comprehensive unit test suite for the Portfolio Optimizer Engine."""

import sys
import os

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from engine import (
    get_default_market_dataset,
    DynamicProgrammingOptimizer,
    MarkowitzOptimizer,
    MonteCarloOptimizer,
    EqualWeightStrategy,
    RiskParityStrategy,
    BacktestEngine
)


def run_tests():
    print("=============================================================")
    print(" RUNNING PORTFOLIO OPTIMIZER ENGINE TEST SUITE")
    print("=============================================================")

    # 1. Dataset verification
    print("\n[1] Verifying 3-Asset & 6-Asset Calibrated Datasets...")
    assets3, corr3 = get_default_market_dataset("3-asset")
    assert len(assets3) == 3, f"Expected 3 assets, got {len(assets3)}"
    for a in assets3:
        assert a.expected_return > 0
        assert a.volatility > 0
        assert len(a.historical_returns) == 10
        print(f"  [PASS] {a.name} ({a.ticker}): Return = {a.expected_return*100:.1f}%, Vol = {a.volatility*100:.1f}%, Category = {a.category}")

    assets6, corr6 = get_default_market_dataset("6-asset")
    assert len(assets6) == 6, f"Expected 6 assets, got {len(assets6)}"
    print(f"  [PASS] 6-Asset Universe Loaded successfully ({len(assets6)} assets).")

    # 2. Dynamic Programming Optimizer Verification
    print("\n[2] Testing Dynamic Programming Optimizer with Various Risk Profiles...")
    dp = DynamicProgrammingOptimizer(step_pct=2.0)

    for risk_tol in [2.0, 5.0, 8.5]:
        p = dp.optimize(assets3, budget=100000.0, risk_tolerance=risk_tol, correlation_matrix=corr3)
        assert abs(sum(p.weights) - 1.0) < 1e-4, f"Weights sum to {sum(p.weights)}, expected 1.0"
        alloc_str = ", ".join([f"{a.ticker}: {w*100:.1f}%" for a, w in zip(assets3, p.weights)])
        print(f"  [PASS] Risk Tol {risk_tol:3.1f} -> {alloc_str}")
        print(f"    Expected Return: {p.expected_return*100:5.2f}% | Volatility: {p.volatility*100:5.2f}% | Sharpe: {p.sharpe_ratio:.3f} | Div Bonus: {p.diversification_bonus_pct:.1f}% | 95% VaR: ${p.value_at_risk(0.95):,.2f}")

    # Verify DP Table inspection
    assert dp.last_dp_table is not None, "DP table must be recorded"
    assert len(dp.last_backtrack_trace) == len(assets3), "Backtrack trace must record decisions for all assets"
    print("  [PASS] DP Table Memoization grid and Backtrack trace validated.")

    # 3. Markowitz MPT & Monte Carlo
    print("\n[3] Testing Markowitz Efficient Frontier & Monte Carlo Simplex...")
    mpt = MarkowitzOptimizer()
    frontier = mpt.generate_efficient_frontier(assets3, corr3, num_points=20)
    assert len(frontier) > 0, "Efficient frontier must generate points"
    print(f"  [PASS] Markowitz Efficient Frontier generated {len(frontier)} Pareto points.")

    mc = MonteCarloOptimizer(num_simulations=500)
    cloud = mc.generate_simulation_cloud(assets3, corr3, n_points=500)
    assert len(cloud) == 500, f"Expected 500 MC points, got {len(cloud)}"
    print(f"  [PASS] Monte Carlo Simplex generated {len(cloud)} points across unit simplex.")

    # 4. Standard Benchmark Strategies
    print("\n[4] Testing Standard Benchmarks (1/N, Risk Parity)...")
    eq_strat = EqualWeightStrategy()
    p_eq = eq_strat.optimize(assets3, 100000.0, 5.0, corr3)
    for w in p_eq.weights:
        assert abs(w - 1.0/3.0) < 1e-3
    print("  [PASS] Equal Weight 1/N verified: all weights exactly 33.33%.")

    rp_strat = RiskParityStrategy()
    p_rp = rp_strat.optimize(assets3, 100000.0, 5.0, corr3)
    # Lowest volatility asset (Debt) should have largest weight
    debt_idx = [i for i, a in enumerate(assets3) if a.category == "Debt"][0]
    eq_idx = [i for i, a in enumerate(assets3) if a.category == "Equity"][0]
    assert p_rp.weights[debt_idx] > p_rp.weights[eq_idx]
    print(f"  [PASS] Risk Parity verified: Debt received higher weight ({p_rp.weights[debt_idx]*100:.1f}%) than Equity ({p_rp.weights[eq_idx]*100:.1f}%).")

    # 5. 10-Year Backtest Engine
    print("\n[5] Testing 10-Year Backtesting Engine (2015-2024)...")
    bt_engine = BacktestEngine()
    bt_res = bt_engine.run_backtest({
        "DP Optimal": p,
        "Equal Weight (1/N)": p_eq,
        "Risk Parity": p_rp
    })
    for name, r in bt_res["strategies"].items():
        print(f"  [PASS] {name:18} -> Final Wealth: ${r['final_wealth']:,.2f} | CAGR: {r['cagr_pct']:5.2f}% | MaxDD: {r['max_drawdown_pct']:5.2f}%")

    # 6. DataManager & CSV Pipeline
    print("\n[6] Testing DataManager CSV Loader & Statistical Computations...")
    from engine import DataManager, PortfolioOptimizer
    dm = DataManager()
    assert len(dm.years) >= 10, f"Expected >= 10 historical years, got {len(dm.years)}"
    for cat in ["Equity", "Debt", "Gold"]:
        s = dm.statistics[cat]
        assert s["mean_return"] > 0, f"{cat} mean return should be positive"
        assert s["volatility"] > 0, f"{cat} volatility should be positive"
        print(f"  [PASS] DataManager {cat:6} -> Mean = {s['mean_return_pct']:5.2f}%, Vol = {s['volatility_pct']:5.2f}%, CAGR = {s['cagr_pct']:5.2f}%")
    assert dm.is_illustrative is True, "Illustrative disclaimer must be flagged"
    assert dm.correlation_matrix is not None
    print(f"  [PASS] DataManager loaded CSV, verified statistics, and generated correlation matrix.")

    # 7. PortfolioOptimizer with INR, Unit Step, Constraints & Risk Ceiling
    print("\n[7] Testing PortfolioOptimizer with INR Budget, Unit Step & Risk Ceiling...")
    inr_budget = 500000.0  # ₹5,00,000
    inr_opt = PortfolioOptimizer(unit_step=5000.0)  # ₹5,000 unit steps
    prepared_assets, p_corr = dm.prepare_assets(
        constraints={
            "Equity": {"min": 0.10, "max": 0.60},
            "Debt": {"min": 0.20, "max": 0.70},
            "Gold": {"min": 0.05, "max": 0.30}
        }
    )
    p_inr = inr_opt.optimize(
        assets=prepared_assets,
        budget=inr_budget,
        risk_tolerance=5.0,
        correlation_matrix=p_corr,
        constraints={"max_portfolio_risk": 0.12}  # Ceiling 12% risk
    )
    assert p_inr.total_budget == inr_budget
    assert abs(sum(p_inr.weights) - 1.0) < 1e-4
    assert p_inr.volatility <= 0.125, f"Portfolio risk {p_inr.volatility*100:.2f}% should not exceed ceiling"
    for a, w in zip(p_inr.assets, p_inr.weights):
        assert w >= a.min_allocation - 1e-3, f"{a.name} weight {w} < min {a.min_allocation}"
        assert w <= a.max_allocation + 1e-3, f"{a.name} weight {w} > max {a.max_allocation}"
    print(f"  [PASS] INR Portfolio allocated across ₹{inr_budget:,.2f} budget with unit steps and constraints:")
    for a, amt in p_inr.allocation_amounts.items():
        pct = p_inr.allocation_percentages[a]
        print(f"         • {a}: ₹{amt:,.2f} ({pct:.1f}%)")
    print(f"         Portfolio Return: {p_inr.expected_return*100:.2f}% | Portfolio Risk: {p_inr.volatility*100:.2f}%")

    print("\n=============================================================")
    print(" ALL 7 TEST MODULES PASSED WITH 100% SUCCESS!")
    print("=============================================================")


if __name__ == "__main__":
    run_tests()
