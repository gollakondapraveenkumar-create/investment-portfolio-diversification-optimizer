# app.py
"""
Flask Web Application for Investment Portfolio Diversification Optimizer.
Provides a modern JSON REST API and serves the dashboard frontend.
Implements Dynamic Programming portfolio allocation, Markowitz Modern Portfolio Theory,
historical CSV data management, and risk-return simulation.
"""

import os
import sys
import json
from typing import Dict, Any

# Ensure stdout handles UTF-8 on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)

from engine import (
    DataManager,
    PortfolioOptimizer,
    DynamicProgrammingOptimizer,
    MarkowitzOptimizer,
    MonteCarloOptimizer,
    EqualWeightStrategy,
    RiskParityStrategy,
    BacktestEngine,
    Portfolio,
    get_default_market_dataset
)

STATIC_DIR = os.path.join(CURRENT_DIR, "static")

# Check if Flask is available
try:
    from flask import Flask, request, jsonify, send_from_directory
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False


def create_app():
    """Application factory for Flask."""
    if not HAS_FLASK:
        return None

    app = Flask(__name__, static_folder=STATIC_DIR, template_folder=STATIC_DIR)

    # Initialize data manager singleton
    data_mgr = DataManager()

    @app.route("/")
    def index():
        return send_from_directory(STATIC_DIR, "index.html")

    @app.route("/<path:filename>")
    def static_files(filename):
        return send_from_directory(STATIC_DIR, filename)

    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify({
            "status": "ok",
            "framework": "Flask",
            "app": "Investment Portfolio Diversification Optimizer",
            "version": "2.0.0"
        })

    @app.route("/api/historical-data", methods=["GET"])
    def historical_data():
        """Returns loaded CSV historical returns, statistics, and correlation matrix."""
        try:
            return jsonify(data_mgr.to_dict())
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.route("/api/assets", methods=["GET"])
    def get_assets():
        mode = request.args.get("mode", "3-asset")
        if mode == "3-asset":
            assets, corr = data_mgr.prepare_assets()
        else:
            assets, corr = get_default_market_dataset(mode)

        return jsonify({
            "mode": mode,
            "assets": [a.to_dict() for a in assets],
            "correlation_matrix": corr.to_dict()
        })

    @app.route("/api/optimize", methods=["POST"])
    def optimize():
        payload = request.get_json(force=True, silent=True) or {}
        try:
            response = execute_optimization(payload, data_mgr)
            return jsonify(response)
        except Exception as e:
            return jsonify({"error": f"Optimization failed: {str(e)}"}), 400

    @app.route("/api/monte-carlo", methods=["POST"])
    def monte_carlo():
        payload = request.get_json(force=True, silent=True) or {}
        mode = payload.get("mode", "3-asset")
        n_points = int(payload.get("simulations", 1500))
        risk_free_rate = float(payload.get("risk_free_rate", 0.035))

        if mode == "3-asset":
            assets, corr = data_mgr.prepare_assets()
        else:
            assets, corr = get_default_market_dataset(mode)

        mc = MonteCarloOptimizer(num_simulations=n_points)
        cloud = mc.generate_simulation_cloud(assets, corr, risk_free_rate, n_points)
        return jsonify({"simulations": len(cloud), "cloud": cloud})

    return app


def execute_optimization(payload: Dict[str, Any], data_mgr: DataManager) -> Dict[str, Any]:
    """Core optimization logic shared across Flask and standard library servers."""
    mode = payload.get("mode", "3-asset")
    budget = float(payload.get("budget", 500000.0))  # Default in ₹ (INR)
    risk_tolerance = float(payload.get("risk_tolerance", 5.0))
    step_pct = float(payload.get("step_pct", 2.0))
    unit_step = float(payload.get("unit_step", 5000.0)) if "unit_step" in payload else None
    risk_free_rate = float(payload.get("risk_free_rate", 0.035))
    max_risk = payload.get("max_risk")
    if max_risk is not None and max_risk != "":
        max_risk = float(max_risk)
        if max_risk > 1.0:  # If passed as percentage (e.g. 15 for 15%)
            max_risk /= 100.0
    else:
        max_risk = None

    custom_returns = payload.get("custom_returns")
    custom_vols = payload.get("custom_volatilities")
    constraints_dict = payload.get("constraints") or {}

    # 1. Prepare asset universe
    if mode == "3-asset":
        assets, corr = data_mgr.prepare_assets(
            custom_returns=custom_returns,
            custom_volatilities=custom_vols,
            constraints=constraints_dict
        )
    else:
        assets, corr = get_default_market_dataset(mode)

    # 2. Dynamic Programming Portfolio Optimization
    dp_opt = PortfolioOptimizer(step_pct=step_pct, unit_step=unit_step)
    dp_constraints = {
        "max_portfolio_risk": max_risk,
        "unit_step": unit_step
    }
    dp_portfolio = dp_opt.optimize(
        assets=assets,
        budget=budget,
        risk_tolerance=risk_tolerance,
        correlation_matrix=corr,
        risk_free_rate=risk_free_rate,
        constraints=dp_constraints
    )

    # 3. Markowitz MPT Optimization & Continuous Frontier
    mpt_opt = MarkowitzOptimizer()
    mpt_portfolio = mpt_opt.optimize(
        assets=assets,
        budget=budget,
        risk_tolerance=risk_tolerance,
        correlation_matrix=corr,
        risk_free_rate=risk_free_rate
    )
    efficient_frontier = mpt_opt.generate_efficient_frontier(
        assets=assets,
        correlation_matrix=corr,
        risk_free_rate=risk_free_rate,
        num_points=35
    )

    # 4. Standard Benchmarks (1/N, Risk Parity, 60/40, 100% Equity)
    eq_opt = EqualWeightStrategy()
    eq_portfolio = eq_opt.optimize(
        assets=assets,
        budget=budget,
        risk_tolerance=risk_tolerance,
        correlation_matrix=corr,
        risk_free_rate=risk_free_rate
    )

    rp_opt = RiskParityStrategy()
    rp_portfolio = rp_opt.optimize(
        assets=assets,
        budget=budget,
        risk_tolerance=risk_tolerance,
        correlation_matrix=corr,
        risk_free_rate=risk_free_rate
    )

    # 100% Equity Benchmark
    eq_weights = [1.0 if a.category == "Equity" and (mode == "3-asset" or "Large" in a.name) else 0.0 for a in assets]
    s_eq = sum(eq_weights)
    if s_eq == 0:
        eq_weights[0] = 1.0
    else:
        eq_weights = [w / s_eq for w in eq_weights]
    equity_only_portfolio = Portfolio(assets, eq_weights, budget, corr, risk_free_rate)

    # 60/40 Equity/Debt Benchmark
    sixty_forty_weights = []
    for a in assets:
        if a.category == "Equity":
            sixty_forty_weights.append(0.60 if mode == "3-asset" else 0.30)
        elif a.category == "Debt":
            sixty_forty_weights.append(0.40 if mode == "3-asset" else 0.20)
        else:
            sixty_forty_weights.append(0.0)
    s_6040 = sum(sixty_forty_weights)
    if s_6040 > 0:
        sixty_forty_weights = [w / s_6040 for w in sixty_forty_weights]
    else:
        sixty_forty_weights = [1.0 / len(assets)] * len(assets)
    sixty_forty_portfolio = Portfolio(assets, sixty_forty_weights, budget, corr, risk_free_rate)

    # 5. 10-Year Backtesting Engine
    backtest = BacktestEngine(years=data_mgr.years if hasattr(data_mgr, 'years') and data_mgr.years else None)
    bt_results = backtest.run_backtest(
        portfolios={
            "DP Optimal": dp_portfolio,
            "Markowitz MPT": mpt_portfolio,
            "Equal Weight (1/N)": eq_portfolio,
            "Risk Parity": rp_portfolio,
            "60/40 Classic": sixty_forty_portfolio,
            "100% Equity": equity_only_portfolio
        },
        initial_capital=budget,
        risk_free_rate=risk_free_rate
    )

    return {
        "parameters": {
            "mode": mode,
            "budget": budget,
            "currency": "INR",
            "risk_tolerance": risk_tolerance,
            "max_risk": max_risk,
            "unit_step": unit_step,
            "step_pct": step_pct,
            "risk_free_rate": risk_free_rate
        },
        "dp_optimal": dp_portfolio.to_dict(),
        "dp_table": dp_opt.last_dp_table,
        "dp_backtrack": dp_opt.last_backtrack_trace,
        "markowitz_optimal": mpt_portfolio.to_dict(),
        "efficient_frontier": efficient_frontier,
        "benchmarks": {
            "equal_weight": eq_portfolio.to_dict(),
            "risk_parity": rp_portfolio.to_dict(),
            "sixty_forty": sixty_forty_portfolio.to_dict(),
            "equity_only": equity_only_portfolio.to_dict()
        },
        "backtest": bt_results,
        "historical_statistics": data_mgr.statistics
    }


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000

    if HAS_FLASK:
        print("===============================================================")
        print(f" Starting Flask Portfolio Optimizer Server at http://localhost:{port}")
        print("===============================================================")
        app = create_app()
        app.run(host="0.0.0.0", port=port, debug=False)
    else:
        print("===============================================================")
        print(" Note: Flask package is not currently installed.")
        print(" To run full Flask: pip install -r requirements.txt")
        print(" Launching zero-dependency standard library server instead...")
        print("===============================================================")
        import server
        server.run(port)
